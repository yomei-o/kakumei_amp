EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Transistor_BJT:2SC1815 Q1
U 1 1 5F56C429
P 4700 1750
F 0 "Q1" H 4890 1796 50  0000 L CNN
F 1 "2SC1815" H 4890 1705 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 4900 1675 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 4700 1750 50  0001 L CNN
	1    4700 1750
	1    0    0    -1  
$EndComp
$Comp
L Transistor_FET:AO3401A Q2
U 1 1 5F56FDA3
P 5500 1550
F 0 "Q2" H 5704 1596 50  0000 L CNN
F 1 "2SJ681GDS" H 5704 1505 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-251-3-1EP_Horizontal_TabDown" H 5700 1475 50  0001 L CIN
F 3 "http://www.aosmd.com/pdfs/datasheet/AO3401A.pdf" H 5500 1550 50  0001 L CNN
	1    5500 1550
	1    0    0    -1  
$EndComp
$Comp
L Device:R R1
U 1 1 5F573BC3
P 4250 1750
F 0 "R1" V 4043 1750 50  0000 C CNN
F 1 "1k" V 4134 1750 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 4180 1750 50  0001 C CNN
F 3 "~" H 4250 1750 50  0001 C CNN
	1    4250 1750
	0    1    1    0   
$EndComp
$Comp
L Device:R R2
U 1 1 5F576194
P 4500 2000
F 0 "R2" V 4293 2000 50  0000 C CNN
F 1 "10k" V 4384 2000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 4430 2000 50  0001 C CNN
F 3 "~" H 4500 2000 50  0001 C CNN
	1    4500 2000
	1    0    0    -1  
$EndComp
$Comp
L Device:R R3
U 1 1 5F576BD0
P 5300 1300
F 0 "R3" V 5093 1300 50  0000 C CNN
F 1 "10k" V 5184 1300 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5230 1300 50  0001 C CNN
F 3 "~" H 5300 1300 50  0001 C CNN
	1    5300 1300
	1    0    0    -1  
$EndComp
$Comp
L Device:R R4
U 1 1 5F5772E1
P 5300 2000
F 0 "R4" V 5093 2000 50  0000 C CNN
F 1 "10k" V 5184 2000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5230 2000 50  0001 C CNN
F 3 "~" H 5300 2000 50  0001 C CNN
	1    5300 2000
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR0101
U 1 1 5F56CE3C
P 5300 950
F 0 "#PWR0101" H 5300 800 50  0001 C CNN
F 1 "VCC" H 5315 1123 50  0000 C CNN
F 2 "" H 5300 950 50  0001 C CNN
F 3 "" H 5300 950 50  0001 C CNN
	1    5300 950 
	1    0    0    -1  
$EndComp
Wire Wire Line
	5300 950  5300 1050
Wire Wire Line
	5300 1550 5300 1450
Wire Wire Line
	5300 1550 5300 1850
Connection ~ 5300 1550
Wire Wire Line
	5300 1050 5600 1050
Wire Wire Line
	5600 1050 5600 1350
Connection ~ 5300 1050
Wire Wire Line
	5300 1050 5300 1150
Wire Wire Line
	4400 1750 4500 1750
Wire Wire Line
	4500 1850 4500 1750
Connection ~ 4500 1750
Wire Wire Line
	4500 2150 4800 2150
Wire Wire Line
	4800 1950 4800 2150
Connection ~ 4800 2150
Text GLabel 4000 1750 0    50   Input ~ 0
IN1
Wire Wire Line
	4000 1750 4100 1750
Text GLabel 6000 1750 2    50   Output ~ 0
OUT1
Wire Wire Line
	5600 1750 6000 1750
$Comp
L power:GND #PWR0102
U 1 1 5F56EBB2
P 4800 2350
F 0 "#PWR0102" H 4800 2100 50  0001 C CNN
F 1 "GND" H 4805 2177 50  0000 C CNN
F 2 "" H 4800 2350 50  0001 C CNN
F 3 "" H 4800 2350 50  0001 C CNN
	1    4800 2350
	1    0    0    -1  
$EndComp
Wire Wire Line
	4800 2350 4800 2150
$Comp
L Connector:Barrel_Jack_Switch J1
U 1 1 5F56F559
P 1050 1150
F 0 "J1" H 1107 1467 50  0000 C CNN
F 1 "Barrel_Jack_Switch" H 1107 1376 50  0000 C CNN
F 2 "Connector_BarrelJack:BarrelJack_Horizontal" H 1100 1110 50  0001 C CNN
F 3 "~" H 1100 1110 50  0001 C CNN
	1    1050 1150
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR03
U 1 1 5F5706EF
P 1700 1400
F 0 "#PWR03" H 1700 1150 50  0001 C CNN
F 1 "GND" H 1705 1227 50  0000 C CNN
F 2 "" H 1700 1400 50  0001 C CNN
F 3 "" H 1700 1400 50  0001 C CNN
	1    1700 1400
	1    0    0    -1  
$EndComp
Wire Wire Line
	1350 1250 1700 1250
Wire Wire Line
	1700 1250 1700 1400
Wire Wire Line
	1350 1150 1350 1250
Connection ~ 1350 1250
$Comp
L Connector:Raspberry_Pi_2_3 J2
U 1 1 5F57249C
P 2000 3550
F 0 "J2" H 2000 5031 50  0000 C CNN
F 1 "Raspberry_Pi_2_3" H 2000 4940 50  0000 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_2x20_P2.54mm_Vertical" H 2000 3550 50  0001 C CNN
F 3 "https://www.raspberrypi.org/documentation/hardware/raspberrypi/schematics/rpi_SCH_3bplus_1p0_reduced.pdf" H 2000 3550 50  0001 C CNN
	1    2000 3550
	1    0    0    -1  
$EndComp
Text GLabel 950  3550 0    50   Output ~ 0
IN1
Text GLabel 950  3450 0    50   Output ~ 0
IN2
Text GLabel 950  2950 0    50   Output ~ 0
IN3
Text GLabel 950  3350 0    50   Output ~ 0
IN4
Wire Wire Line
	950  2950 1200 2950
Wire Wire Line
	950  3350 1200 3350
Wire Wire Line
	950  3450 1200 3450
Wire Wire Line
	950  3550 1200 3550
Wire Wire Line
	1900 4850 1800 4850
Connection ~ 1900 4850
Wire Wire Line
	1800 4850 1700 4850
Connection ~ 1800 4850
Wire Wire Line
	1700 4850 1600 4850
Connection ~ 1700 4850
Wire Wire Line
	2000 4850 2100 4850
Connection ~ 2000 4850
Wire Wire Line
	2100 4850 2200 4850
Connection ~ 2100 4850
Wire Wire Line
	2200 4850 2300 4850
Connection ~ 2200 4850
Wire Wire Line
	1900 4850 2000 4850
$Comp
L power:GND #PWR01
U 1 1 5F58CDAF
P 1600 5000
F 0 "#PWR01" H 1600 4750 50  0001 C CNN
F 1 "GND" H 1605 4827 50  0000 C CNN
F 2 "" H 1600 5000 50  0001 C CNN
F 3 "" H 1600 5000 50  0001 C CNN
	1    1600 5000
	1    0    0    -1  
$EndComp
Wire Wire Line
	1600 5000 1600 4850
Connection ~ 1600 4850
$Comp
L Transistor_BJT:2SC1815 Q3
U 1 1 5F5C032E
P 4700 3750
F 0 "Q3" H 4890 3796 50  0000 L CNN
F 1 "2SC1815" H 4890 3705 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 4900 3675 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 4700 3750 50  0001 L CNN
	1    4700 3750
	1    0    0    -1  
$EndComp
$Comp
L Transistor_FET:AO3401A Q4
U 1 1 5F5C0334
P 5500 3550
F 0 "Q4" H 5704 3596 50  0000 L CNN
F 1 "2SJ681GDS" H 5704 3505 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-251-3-1EP_Horizontal_TabDown" H 5700 3475 50  0001 L CIN
F 3 "http://www.aosmd.com/pdfs/datasheet/AO3401A.pdf" H 5500 3550 50  0001 L CNN
	1    5500 3550
	1    0    0    -1  
$EndComp
$Comp
L Device:R R5
U 1 1 5F5C033A
P 4250 3750
F 0 "R5" V 4043 3750 50  0000 C CNN
F 1 "1k" V 4134 3750 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 4180 3750 50  0001 C CNN
F 3 "~" H 4250 3750 50  0001 C CNN
	1    4250 3750
	0    1    1    0   
$EndComp
$Comp
L Device:R R6
U 1 1 5F5C0340
P 4500 4000
F 0 "R6" V 4293 4000 50  0000 C CNN
F 1 "10k" V 4384 4000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 4430 4000 50  0001 C CNN
F 3 "~" H 4500 4000 50  0001 C CNN
	1    4500 4000
	1    0    0    -1  
$EndComp
$Comp
L Device:R R7
U 1 1 5F5C0346
P 5300 3300
F 0 "R7" V 5093 3300 50  0000 C CNN
F 1 "10k" V 5184 3300 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5230 3300 50  0001 C CNN
F 3 "~" H 5300 3300 50  0001 C CNN
	1    5300 3300
	1    0    0    -1  
$EndComp
$Comp
L Device:R R8
U 1 1 5F5C034C
P 5300 4000
F 0 "R8" V 5093 4000 50  0000 C CNN
F 1 "10k" V 5184 4000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5230 4000 50  0001 C CNN
F 3 "~" H 5300 4000 50  0001 C CNN
	1    5300 4000
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR09
U 1 1 5F5C0352
P 5300 2950
F 0 "#PWR09" H 5300 2800 50  0001 C CNN
F 1 "VCC" H 5315 3123 50  0000 C CNN
F 2 "" H 5300 2950 50  0001 C CNN
F 3 "" H 5300 2950 50  0001 C CNN
	1    5300 2950
	1    0    0    -1  
$EndComp
Wire Wire Line
	5300 2950 5300 3050
Wire Wire Line
	5300 3550 5300 3450
Wire Wire Line
	5300 3550 5300 3850
Connection ~ 5300 3550
Wire Wire Line
	5300 3050 5600 3050
Wire Wire Line
	5600 3050 5600 3350
Connection ~ 5300 3050
Wire Wire Line
	5300 3050 5300 3150
Wire Wire Line
	4400 3750 4500 3750
Wire Wire Line
	4500 3850 4500 3750
Connection ~ 4500 3750
Wire Wire Line
	4500 4150 4800 4150
Wire Wire Line
	4800 3950 4800 4150
Connection ~ 4800 4150
Text GLabel 4000 3750 0    50   Input ~ 0
IN2
Wire Wire Line
	4000 3750 4100 3750
Text GLabel 6000 3750 2    50   Output ~ 0
OUT2
Wire Wire Line
	5600 3750 6000 3750
$Comp
L power:GND #PWR06
U 1 1 5F5C036C
P 4800 4350
F 0 "#PWR06" H 4800 4100 50  0001 C CNN
F 1 "GND" H 4805 4177 50  0000 C CNN
F 2 "" H 4800 4350 50  0001 C CNN
F 3 "" H 4800 4350 50  0001 C CNN
	1    4800 4350
	1    0    0    -1  
$EndComp
Wire Wire Line
	4800 4350 4800 4150
$Comp
L Transistor_BJT:2SC1815 Q5
U 1 1 5F5D4098
P 7700 1750
F 0 "Q5" H 7890 1796 50  0000 L CNN
F 1 "2SC1815" H 7890 1705 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 7900 1675 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 7700 1750 50  0001 L CNN
	1    7700 1750
	1    0    0    -1  
$EndComp
$Comp
L Transistor_FET:AO3401A Q6
U 1 1 5F5D40A2
P 8500 1550
F 0 "Q6" H 8704 1596 50  0000 L CNN
F 1 "2SJ681GDS" H 8704 1505 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-251-3-1EP_Horizontal_TabDown" H 8700 1475 50  0001 L CIN
F 3 "http://www.aosmd.com/pdfs/datasheet/AO3401A.pdf" H 8500 1550 50  0001 L CNN
	1    8500 1550
	1    0    0    -1  
$EndComp
$Comp
L Device:R R9
U 1 1 5F5D40AC
P 7250 1750
F 0 "R9" V 7043 1750 50  0000 C CNN
F 1 "1k" V 7134 1750 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7180 1750 50  0001 C CNN
F 3 "~" H 7250 1750 50  0001 C CNN
	1    7250 1750
	0    1    1    0   
$EndComp
$Comp
L Device:R R10
U 1 1 5F5D40B6
P 7500 2000
F 0 "R10" V 7293 2000 50  0000 C CNN
F 1 "10k" V 7384 2000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7430 2000 50  0001 C CNN
F 3 "~" H 7500 2000 50  0001 C CNN
	1    7500 2000
	1    0    0    -1  
$EndComp
$Comp
L Device:R R11
U 1 1 5F5D40C0
P 8300 1300
F 0 "R11" V 8093 1300 50  0000 C CNN
F 1 "10k" V 8184 1300 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 8230 1300 50  0001 C CNN
F 3 "~" H 8300 1300 50  0001 C CNN
	1    8300 1300
	1    0    0    -1  
$EndComp
$Comp
L Device:R R12
U 1 1 5F5D40CA
P 8300 2000
F 0 "R12" V 8093 2000 50  0000 C CNN
F 1 "10k" V 8184 2000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 8230 2000 50  0001 C CNN
F 3 "~" H 8300 2000 50  0001 C CNN
	1    8300 2000
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR012
U 1 1 5F5D40D4
P 8300 950
F 0 "#PWR012" H 8300 800 50  0001 C CNN
F 1 "VCC" H 8315 1123 50  0000 C CNN
F 2 "" H 8300 950 50  0001 C CNN
F 3 "" H 8300 950 50  0001 C CNN
	1    8300 950 
	1    0    0    -1  
$EndComp
Wire Wire Line
	8300 950  8300 1050
Wire Wire Line
	8300 1550 8300 1450
Wire Wire Line
	8300 1550 8300 1850
Connection ~ 8300 1550
Wire Wire Line
	8300 1050 8600 1050
Wire Wire Line
	8600 1050 8600 1350
Connection ~ 8300 1050
Wire Wire Line
	8300 1050 8300 1150
Wire Wire Line
	7400 1750 7500 1750
Wire Wire Line
	7500 1850 7500 1750
Connection ~ 7500 1750
Wire Wire Line
	7500 2150 7800 2150
Wire Wire Line
	7800 1950 7800 2150
Connection ~ 7800 2150
Text GLabel 7000 1750 0    50   Input ~ 0
IN3
Wire Wire Line
	7000 1750 7100 1750
Text GLabel 9000 1750 2    50   Output ~ 0
OUT3
Wire Wire Line
	8600 1750 9000 1750
$Comp
L power:GND #PWR010
U 1 1 5F5D40F2
P 7800 2350
F 0 "#PWR010" H 7800 2100 50  0001 C CNN
F 1 "GND" H 7805 2177 50  0000 C CNN
F 2 "" H 7800 2350 50  0001 C CNN
F 3 "" H 7800 2350 50  0001 C CNN
	1    7800 2350
	1    0    0    -1  
$EndComp
Wire Wire Line
	7800 2350 7800 2150
$Comp
L Transistor_BJT:2SC1815 Q7
U 1 1 5F5D40FD
P 7700 3750
F 0 "Q7" H 7890 3796 50  0000 L CNN
F 1 "2SC1815" H 7890 3705 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 7900 3675 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 7700 3750 50  0001 L CNN
	1    7700 3750
	1    0    0    -1  
$EndComp
$Comp
L Transistor_FET:AO3401A Q8
U 1 1 5F5D4107
P 8500 3550
F 0 "Q8" H 8704 3596 50  0000 L CNN
F 1 "2SJ681GDS" H 8704 3505 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-251-3-1EP_Horizontal_TabDown" H 8700 3475 50  0001 L CIN
F 3 "http://www.aosmd.com/pdfs/datasheet/AO3401A.pdf" H 8500 3550 50  0001 L CNN
	1    8500 3550
	1    0    0    -1  
$EndComp
$Comp
L Device:R R13
U 1 1 5F5D4111
P 7250 3750
F 0 "R13" V 7043 3750 50  0000 C CNN
F 1 "1k" V 7134 3750 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7180 3750 50  0001 C CNN
F 3 "~" H 7250 3750 50  0001 C CNN
	1    7250 3750
	0    1    1    0   
$EndComp
$Comp
L Device:R R14
U 1 1 5F5D411B
P 7500 4000
F 0 "R14" V 7293 4000 50  0000 C CNN
F 1 "10k" V 7384 4000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7430 4000 50  0001 C CNN
F 3 "~" H 7500 4000 50  0001 C CNN
	1    7500 4000
	1    0    0    -1  
$EndComp
$Comp
L Device:R R15
U 1 1 5F5D4125
P 8300 3300
F 0 "R15" V 8093 3300 50  0000 C CNN
F 1 "10k" V 8184 3300 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 8230 3300 50  0001 C CNN
F 3 "~" H 8300 3300 50  0001 C CNN
	1    8300 3300
	1    0    0    -1  
$EndComp
$Comp
L Device:R R16
U 1 1 5F5D412F
P 8300 4000
F 0 "R16" V 8093 4000 50  0000 C CNN
F 1 "10k" V 8184 4000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 8230 4000 50  0001 C CNN
F 3 "~" H 8300 4000 50  0001 C CNN
	1    8300 4000
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR013
U 1 1 5F5D4139
P 8300 2950
F 0 "#PWR013" H 8300 2800 50  0001 C CNN
F 1 "VCC" H 8315 3123 50  0000 C CNN
F 2 "" H 8300 2950 50  0001 C CNN
F 3 "" H 8300 2950 50  0001 C CNN
	1    8300 2950
	1    0    0    -1  
$EndComp
Wire Wire Line
	8300 2950 8300 3050
Wire Wire Line
	8300 3550 8300 3450
Wire Wire Line
	8300 3550 8300 3850
Connection ~ 8300 3550
Wire Wire Line
	8300 3050 8600 3050
Wire Wire Line
	8600 3050 8600 3350
Connection ~ 8300 3050
Wire Wire Line
	8300 3050 8300 3150
Wire Wire Line
	7400 3750 7500 3750
Wire Wire Line
	7500 3850 7500 3750
Connection ~ 7500 3750
Wire Wire Line
	7500 4150 7800 4150
Wire Wire Line
	7800 3950 7800 4150
Connection ~ 7800 4150
Text GLabel 7000 3750 0    50   Input ~ 0
IN4
Wire Wire Line
	7000 3750 7100 3750
Text GLabel 9000 3750 2    50   Output ~ 0
OUT4
Wire Wire Line
	8600 3750 9000 3750
$Comp
L power:GND #PWR011
U 1 1 5F5D4157
P 7800 4350
F 0 "#PWR011" H 7800 4100 50  0001 C CNN
F 1 "GND" H 7805 4177 50  0000 C CNN
F 2 "" H 7800 4350 50  0001 C CNN
F 3 "" H 7800 4350 50  0001 C CNN
	1    7800 4350
	1    0    0    -1  
$EndComp
Wire Wire Line
	7800 4350 7800 4150
$Comp
L Connector_Generic:Conn_01x03 J3
U 1 1 5F61A02B
P 4150 5300
F 0 "J3" H 4230 5292 50  0000 L CNN
F 1 "Conn_01x02" H 4230 5201 50  0000 L CNN
F 2 "TerminalBlock:TerminalBlock_bornier-3_P5.08mm" H 4150 5300 50  0001 C CNN
F 3 "~" H 4150 5300 50  0001 C CNN
	1    4150 5300
	1    0    0    -1  
$EndComp
Text GLabel 3800 5300 0    50   Input ~ 0
OUT1
Wire Wire Line
	3800 5300 3950 5300
$Comp
L power:GND #PWR04
U 1 1 5F61D342
P 3850 5600
F 0 "#PWR04" H 3850 5350 50  0001 C CNN
F 1 "GND" H 3855 5427 50  0000 C CNN
F 2 "" H 3850 5600 50  0001 C CNN
F 3 "" H 3850 5600 50  0001 C CNN
	1    3850 5600
	1    0    0    -1  
$EndComp
Wire Wire Line
	3850 5600 3850 5400
Wire Wire Line
	3850 5400 3950 5400
$Comp
L Connector_Generic:Conn_01x03 J5
U 1 1 5F61FF35
P 5450 5300
F 0 "J5" H 5530 5292 50  0000 L CNN
F 1 "Conn_01x02" H 5530 5201 50  0000 L CNN
F 2 "TerminalBlock:TerminalBlock_bornier-3_P5.08mm" H 5450 5300 50  0001 C CNN
F 3 "~" H 5450 5300 50  0001 C CNN
	1    5450 5300
	1    0    0    -1  
$EndComp
Text GLabel 5100 5300 0    50   Input ~ 0
OUT2
Wire Wire Line
	5100 5300 5250 5300
$Comp
L power:GND #PWR07
U 1 1 5F61FF41
P 5150 5600
F 0 "#PWR07" H 5150 5350 50  0001 C CNN
F 1 "GND" H 5155 5427 50  0000 C CNN
F 2 "" H 5150 5600 50  0001 C CNN
F 3 "" H 5150 5600 50  0001 C CNN
	1    5150 5600
	1    0    0    -1  
$EndComp
Wire Wire Line
	5150 5600 5150 5400
Wire Wire Line
	5150 5400 5250 5400
$Comp
L Connector_Generic:Conn_01x03 J4
U 1 1 5F62262A
P 4150 6400
F 0 "J4" H 4230 6392 50  0000 L CNN
F 1 "Conn_01x02" H 4230 6301 50  0000 L CNN
F 2 "TerminalBlock:TerminalBlock_bornier-3_P5.08mm" H 4150 6400 50  0001 C CNN
F 3 "~" H 4150 6400 50  0001 C CNN
	1    4150 6400
	1    0    0    -1  
$EndComp
Text GLabel 3800 6400 0    50   Input ~ 0
OUT3
Wire Wire Line
	3800 6400 3950 6400
$Comp
L power:GND #PWR05
U 1 1 5F622636
P 3850 6700
F 0 "#PWR05" H 3850 6450 50  0001 C CNN
F 1 "GND" H 3855 6527 50  0000 C CNN
F 2 "" H 3850 6700 50  0001 C CNN
F 3 "" H 3850 6700 50  0001 C CNN
	1    3850 6700
	1    0    0    -1  
$EndComp
Wire Wire Line
	3850 6700 3850 6500
Wire Wire Line
	3850 6500 3950 6500
$Comp
L Connector_Generic:Conn_01x03 J6
U 1 1 5F622642
P 5450 6400
F 0 "J6" H 5530 6392 50  0000 L CNN
F 1 "Conn_01x02" H 5530 6301 50  0000 L CNN
F 2 "TerminalBlock:TerminalBlock_bornier-3_P5.08mm" H 5450 6400 50  0001 C CNN
F 3 "~" H 5450 6400 50  0001 C CNN
	1    5450 6400
	1    0    0    -1  
$EndComp
Text GLabel 5100 6400 0    50   Input ~ 0
OUT4
Wire Wire Line
	5100 6400 5250 6400
$Comp
L power:GND #PWR08
U 1 1 5F62264E
P 5150 6700
F 0 "#PWR08" H 5150 6450 50  0001 C CNN
F 1 "GND" H 5155 6527 50  0000 C CNN
F 2 "" H 5150 6700 50  0001 C CNN
F 3 "" H 5150 6700 50  0001 C CNN
	1    5150 6700
	1    0    0    -1  
$EndComp
Wire Wire Line
	5150 6700 5150 6500
Wire Wire Line
	5150 6500 5250 6500
NoConn ~ 2800 2650
NoConn ~ 2800 2750
NoConn ~ 2800 2950
NoConn ~ 2800 3050
NoConn ~ 2800 3250
NoConn ~ 2800 3350
NoConn ~ 2800 3450
NoConn ~ 2800 3650
NoConn ~ 2800 3750
NoConn ~ 2800 3850
NoConn ~ 2800 3950
NoConn ~ 2800 4050
NoConn ~ 2800 4250
NoConn ~ 2800 4350
NoConn ~ 1200 2650
NoConn ~ 1200 2750
NoConn ~ 1200 3050
NoConn ~ 1200 3150
NoConn ~ 1200 3750
NoConn ~ 1200 3850
NoConn ~ 1200 3950
NoConn ~ 1200 4050
NoConn ~ 1200 4150
NoConn ~ 1200 4250
NoConn ~ 2100 2250
NoConn ~ 2200 2250
$Comp
L Connector_Generic:Conn_01x02 J7
U 1 1 5F65D673
P 1850 5800
F 0 "J7" H 1930 5792 50  0000 L CNN
F 1 "Conn_01x02" H 1930 5701 50  0000 L CNN
F 2 "TerminalBlock:TerminalBlock_bornier-2_P5.08mm" H 1850 5800 50  0001 C CNN
F 3 "~" H 1850 5800 50  0001 C CNN
	1    1850 5800
	1    0    0    -1  
$EndComp
Wire Wire Line
	1500 5800 1650 5800
$Comp
L power:GND #PWR015
U 1 1 5F65D67F
P 1550 6100
F 0 "#PWR015" H 1550 5850 50  0001 C CNN
F 1 "GND" H 1555 5927 50  0000 C CNN
F 2 "" H 1550 6100 50  0001 C CNN
F 3 "" H 1550 6100 50  0001 C CNN
	1    1550 6100
	1    0    0    -1  
$EndComp
Wire Wire Line
	1550 6100 1550 5900
Wire Wire Line
	1550 5900 1650 5900
$Comp
L power:VCC #PWR014
U 1 1 5F663014
P 1500 5600
F 0 "#PWR014" H 1500 5450 50  0001 C CNN
F 1 "VCC" H 1515 5773 50  0000 C CNN
F 2 "" H 1500 5600 50  0001 C CNN
F 3 "" H 1500 5600 50  0001 C CNN
	1    1500 5600
	1    0    0    -1  
$EndComp
Wire Wire Line
	1500 5600 1500 5800
$Comp
L Connector_Generic:Conn_01x02 J8
U 1 1 5F666D24
P 1250 2050
F 0 "J8" H 1168 1725 50  0000 C CNN
F 1 "Conn_01x02" H 1168 1816 50  0000 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 1250 2050 50  0001 C CNN
F 3 "~" H 1250 2050 50  0001 C CNN
	1    1250 2050
	-1   0    0    1   
$EndComp
Wire Wire Line
	1800 2250 1900 2250
Wire Wire Line
	1450 2050 1800 2050
Wire Wire Line
	1800 2050 1800 2250
Connection ~ 1800 2250
$Comp
L power:VCC #PWR016
U 1 1 5F672C1D
P 1700 1850
F 0 "#PWR016" H 1700 1700 50  0001 C CNN
F 1 "VCC" H 1715 2023 50  0000 C CNN
F 2 "" H 1700 1850 50  0001 C CNN
F 3 "" H 1700 1850 50  0001 C CNN
	1    1700 1850
	1    0    0    -1  
$EndComp
Wire Wire Line
	1700 1850 1700 1950
Wire Wire Line
	1700 1950 1450 1950
Wire Wire Line
	5300 2150 5050 2150
Wire Wire Line
	5050 2150 5050 1550
Wire Wire Line
	5050 1550 4800 1550
Wire Wire Line
	8300 2150 8050 2150
Wire Wire Line
	8050 2150 8050 1550
Wire Wire Line
	8050 1550 7800 1550
Wire Wire Line
	5300 4150 5050 4150
Wire Wire Line
	5050 4150 5050 3550
Wire Wire Line
	5050 3550 4800 3550
Wire Wire Line
	8300 4150 8050 4150
Wire Wire Line
	8050 4150 8050 3550
Wire Wire Line
	8050 3550 7800 3550
$Comp
L power:VCC #PWR?
U 1 1 5F572BF2
P 3950 5050
F 0 "#PWR?" H 3950 4900 50  0001 C CNN
F 1 "VCC" H 3965 5223 50  0000 C CNN
F 2 "" H 3950 5050 50  0001 C CNN
F 3 "" H 3950 5050 50  0001 C CNN
	1    3950 5050
	1    0    0    -1  
$EndComp
Wire Wire Line
	3950 5050 3950 5200
$Comp
L power:VCC #PWR?
U 1 1 5F579F74
P 5250 5050
F 0 "#PWR?" H 5250 4900 50  0001 C CNN
F 1 "VCC" H 5265 5223 50  0000 C CNN
F 2 "" H 5250 5050 50  0001 C CNN
F 3 "" H 5250 5050 50  0001 C CNN
	1    5250 5050
	1    0    0    -1  
$EndComp
Wire Wire Line
	5250 5050 5250 5200
$Comp
L power:VCC #PWR?
U 1 1 5F587206
P 5250 6150
F 0 "#PWR?" H 5250 6000 50  0001 C CNN
F 1 "VCC" H 5265 6323 50  0000 C CNN
F 2 "" H 5250 6150 50  0001 C CNN
F 3 "" H 5250 6150 50  0001 C CNN
	1    5250 6150
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR?
U 1 1 5F58A782
P 3950 6150
F 0 "#PWR?" H 3950 6000 50  0001 C CNN
F 1 "VCC" H 3965 6323 50  0000 C CNN
F 2 "" H 3950 6150 50  0001 C CNN
F 3 "" H 3950 6150 50  0001 C CNN
	1    3950 6150
	1    0    0    -1  
$EndComp
Wire Wire Line
	5250 6150 5250 6300
Wire Wire Line
	3950 6150 3950 6300
Wire Wire Line
	1800 2050 1800 1050
Wire Wire Line
	1350 1050 1800 1050
Connection ~ 1800 2050
$EndSCHEMATC
