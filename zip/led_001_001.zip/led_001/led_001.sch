EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Device:R R1
U 1 1 5F5574B0
P 3650 2800
F 0 "R1" V 3443 2800 50  0000 C CNN
F 1 "1k" V 3534 2800 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 3580 2800 50  0001 C CNN
F 3 "~" H 3650 2800 50  0001 C CNN
	1    3650 2800
	0    1    1    0   
$EndComp
$Comp
L Device:LED D1
U 1 1 5F557C75
P 4150 2800
F 0 "D1" H 4143 2545 50  0000 C CNN
F 1 "LED" H 4143 2636 50  0000 C CNN
F 2 "LED_THT:LED_D3.0mm" H 4150 2800 50  0001 C CNN
F 3 "~" H 4150 2800 50  0001 C CNN
	1    4150 2800
	-1   0    0    1   
$EndComp
$Comp
L Connector:Barrel_Jack_Switch J1
U 1 1 5F5596C3
P 2700 2850
F 0 "J1" H 2757 3167 50  0000 C CNN
F 1 "Barrel_Jack_Switch" H 2757 3076 50  0000 C CNN
F 2 "Connector_BarrelJack:BarrelJack_Horizontal" H 2750 2810 50  0001 C CNN
F 3 "~" H 2750 2810 50  0001 C CNN
	1    2700 2850
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR02
U 1 1 5F55CC52
P 3300 3250
F 0 "#PWR02" H 3300 3000 50  0001 C CNN
F 1 "GND" H 3305 3077 50  0000 C CNN
F 2 "" H 3300 3250 50  0001 C CNN
F 3 "" H 3300 3250 50  0001 C CNN
	1    3300 3250
	1    0    0    -1  
$EndComp
$Comp
L power:VCC #PWR01
U 1 1 5F55D329
P 3300 2500
F 0 "#PWR01" H 3300 2350 50  0001 C CNN
F 1 "VCC" H 3315 2673 50  0000 C CNN
F 2 "" H 3300 2500 50  0001 C CNN
F 3 "" H 3300 2500 50  0001 C CNN
	1    3300 2500
	1    0    0    -1  
$EndComp
Wire Wire Line
	3800 2800 4000 2800
Wire Wire Line
	4300 2800 4300 2950
Wire Wire Line
	3000 2850 3000 2950
Wire Wire Line
	3000 2950 3300 2950
Wire Wire Line
	3300 2950 3300 3250
Connection ~ 3000 2950
Wire Wire Line
	3300 2950 4300 2950
Connection ~ 3300 2950
Wire Wire Line
	3500 2750 3500 2800
Wire Wire Line
	3300 2500 3300 2750
Wire Wire Line
	3000 2750 3300 2750
Connection ~ 3300 2750
Wire Wire Line
	3300 2750 3500 2750
$EndSCHEMATC
