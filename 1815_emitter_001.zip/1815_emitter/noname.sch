EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Device:C C1
U 1 1 5F605A3D
P 1450 1950
F 0 "C1" V 1198 1950 50  0000 C CNN
F 1 "15uF" V 1289 1950 50  0000 C CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 1488 1800 50  0001 C CNN
F 3 "~" H 1450 1950 50  0001 C CNN
	1    1450 1950
	0    1    1    0   
$EndComp
Text GLabel 1100 1950 0    50   Input ~ 0
IN1
Wire Wire Line
	1100 1950 1300 1950
$Comp
L Device:R R1
U 1 1 5F605C11
P 1800 1700
F 0 "R1" H 1870 1746 50  0000 L CNN
F 1 "180k" H 1870 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1730 1700 50  0001 C CNN
F 3 "~" H 1800 1700 50  0001 C CNN
	1    1800 1700
	1    0    0    -1  
$EndComp
Wire Wire Line
	1600 1950 1800 1950
Wire Wire Line
	1800 1950 1800 1850
$Comp
L power:VCC #PWR01
U 1 1 5F6062B6
P 1800 1250
F 0 "#PWR01" H 1800 1100 50  0001 C CNN
F 1 "VCC" H 1815 1423 50  0000 C CNN
F 2 "" H 1800 1250 50  0001 C CNN
F 3 "" H 1800 1250 50  0001 C CNN
	1    1800 1250
	1    0    0    -1  
$EndComp
Wire Wire Line
	1800 1250 1800 1400
$Comp
L Transistor_BJT:2SC1815 Q1
U 1 1 5F606B2E
P 2200 1950
F 0 "Q1" H 2390 1996 50  0000 L CNN
F 1 "2SC1815" H 2390 1905 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 2400 1875 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 2200 1950 50  0001 L CNN
	1    2200 1950
	1    0    0    -1  
$EndComp
Wire Wire Line
	1800 1950 2000 1950
Connection ~ 1800 1950
$Comp
L Device:R R2
U 1 1 5F607AD5
P 2300 2450
F 0 "R2" H 2370 2496 50  0000 L CNN
F 1 "1k" H 2370 2405 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 2230 2450 50  0001 C CNN
F 3 "~" H 2300 2450 50  0001 C CNN
	1    2300 2450
	1    0    0    -1  
$EndComp
Wire Wire Line
	2300 2150 2300 2300
Wire Wire Line
	1800 1400 2300 1400
Wire Wire Line
	2300 1400 2300 1750
Connection ~ 1800 1400
Wire Wire Line
	1800 1400 1800 1550
$Comp
L Device:C C2
U 1 1 5F6092F3
P 2850 2150
F 0 "C2" V 2598 2150 50  0000 C CNN
F 1 "33uF" V 2689 2150 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D8.0mm_P5.00mm" H 2888 2000 50  0001 C CNN
F 3 "~" H 2850 2150 50  0001 C CNN
	1    2850 2150
	0    1    1    0   
$EndComp
Connection ~ 2300 2150
Wire Wire Line
	2300 2150 2700 2150
Wire Wire Line
	2300 1400 2650 1400
Wire Wire Line
	3000 1400 3000 1550
Connection ~ 2300 1400
Wire Wire Line
	3000 1850 3000 2150
$Comp
L Device:R R4
U 1 1 5F609F9F
P 3000 1700
F 0 "R4" H 3070 1746 50  0000 L CNN
F 1 "4.7k" H 3070 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 2930 1700 50  0001 C CNN
F 3 "~" H 3000 1700 50  0001 C CNN
	1    3000 1700
	1    0    0    -1  
$EndComp
$Comp
L Device:R R3
U 1 1 5F60AADF
P 2650 1700
F 0 "R3" H 2720 1746 50  0000 L CNN
F 1 "8.2k" H 2720 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 2580 1700 50  0001 C CNN
F 3 "~" H 2650 1700 50  0001 C CNN
	1    2650 1700
	1    0    0    -1  
$EndComp
Wire Wire Line
	2650 1400 2650 1550
Connection ~ 2650 1400
Wire Wire Line
	2650 1400 3000 1400
$Comp
L Transistor_BJT:2SC1815 Q2
U 1 1 5F60B053
P 3300 2150
F 0 "Q2" H 3490 2196 50  0000 L CNN
F 1 "2SC1815" H 3490 2105 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 3500 2075 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 3300 2150 50  0001 L CNN
	1    3300 2150
	1    0    0    -1  
$EndComp
Wire Wire Line
	3000 2150 3100 2150
Connection ~ 3000 2150
Wire Wire Line
	3000 1400 3400 1400
Wire Wire Line
	3400 1400 3400 1950
Connection ~ 3000 1400
$Comp
L Transistor_BJT:2SC1815 Q3
U 1 1 5F60BE88
P 3300 2650
F 0 "Q3" H 3490 2696 50  0000 L CNN
F 1 "2SC1815" H 3490 2605 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 3500 2575 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 3300 2650 50  0001 L CNN
	1    3300 2650
	1    0    0    -1  
$EndComp
Wire Wire Line
	3400 2350 3400 2400
Wire Wire Line
	2650 1850 2650 2650
Wire Wire Line
	2650 2650 3100 2650
$Comp
L power:GND #PWR02
U 1 1 5F60C955
P 2300 2750
F 0 "#PWR02" H 2300 2500 50  0001 C CNN
F 1 "GND" H 2305 2577 50  0000 C CNN
F 2 "" H 2300 2750 50  0001 C CNN
F 3 "" H 2300 2750 50  0001 C CNN
	1    2300 2750
	1    0    0    -1  
$EndComp
Wire Wire Line
	2300 2600 2300 2750
$Comp
L Device:LED D1
U 1 1 5F60D40D
P 2650 2800
F 0 "D1" V 2689 2682 50  0000 R CNN
F 1 "LED" V 2598 2682 50  0000 R CNN
F 2 "LED_THT:LED_D3.0mm" H 2650 2800 50  0001 C CNN
F 3 "~" H 2650 2800 50  0001 C CNN
	1    2650 2800
	0    -1   -1   0   
$EndComp
Connection ~ 2650 2650
$Comp
L power:GND #PWR03
U 1 1 5F60DC58
P 2650 3050
F 0 "#PWR03" H 2650 2800 50  0001 C CNN
F 1 "GND" H 2655 2877 50  0000 C CNN
F 2 "" H 2650 3050 50  0001 C CNN
F 3 "" H 2650 3050 50  0001 C CNN
	1    2650 3050
	1    0    0    -1  
$EndComp
Wire Wire Line
	2650 3050 2650 2950
$Comp
L Device:R R5
U 1 1 5F60E3DD
P 3400 3100
F 0 "R5" H 3470 3146 50  0000 L CNN
F 1 "15" H 3470 3055 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 3330 3100 50  0001 C CNN
F 3 "~" H 3400 3100 50  0001 C CNN
	1    3400 3100
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR04
U 1 1 5F60EA26
P 3400 3300
F 0 "#PWR04" H 3400 3050 50  0001 C CNN
F 1 "GND" H 3405 3127 50  0000 C CNN
F 2 "" H 3400 3300 50  0001 C CNN
F 3 "" H 3400 3300 50  0001 C CNN
	1    3400 3300
	1    0    0    -1  
$EndComp
Wire Wire Line
	3400 3250 3400 3300
Wire Wire Line
	3400 2950 3400 2850
$Comp
L Device:CP C4
U 1 1 5F60F7AF
P 3950 2400
F 0 "C4" V 4205 2400 50  0000 C CNN
F 1 "1000uF" V 4114 2400 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 3988 2250 50  0001 C CNN
F 3 "~" H 3950 2400 50  0001 C CNN
	1    3950 2400
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3400 2400 3800 2400
Connection ~ 3400 2400
Wire Wire Line
	3400 2400 3400 2450
$Comp
L Device:CP C3
U 1 1 5F6104B9
P 3750 1550
F 0 "C3" H 3868 1596 50  0000 L CNN
F 1 "2200uF" H 3868 1505 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 3788 1400 50  0001 C CNN
F 3 "~" H 3750 1550 50  0001 C CNN
	1    3750 1550
	1    0    0    -1  
$EndComp
Wire Wire Line
	3750 1400 3400 1400
Connection ~ 3400 1400
$Comp
L power:GND #PWR05
U 1 1 5F6114D2
P 3750 1800
F 0 "#PWR05" H 3750 1550 50  0001 C CNN
F 1 "GND" H 3755 1627 50  0000 C CNN
F 2 "" H 3750 1800 50  0001 C CNN
F 3 "" H 3750 1800 50  0001 C CNN
	1    3750 1800
	1    0    0    -1  
$EndComp
Wire Wire Line
	3750 1700 3750 1800
Text GLabel 4400 2400 2    50   Output ~ 0
OUT1
Wire Wire Line
	4100 2400 4400 2400
$Comp
L Device:C C5
U 1 1 5F6230EA
P 5500 1950
F 0 "C5" V 5248 1950 50  0000 C CNN
F 1 "15uF" V 5339 1950 50  0000 C CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 5538 1800 50  0001 C CNN
F 3 "~" H 5500 1950 50  0001 C CNN
	1    5500 1950
	0    1    1    0   
$EndComp
Text GLabel 5150 1950 0    50   Input ~ 0
IN2
Wire Wire Line
	5150 1950 5350 1950
$Comp
L Device:R R6
U 1 1 5F6230F6
P 5850 1700
F 0 "R6" H 5920 1746 50  0000 L CNN
F 1 "180k" H 5920 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5780 1700 50  0001 C CNN
F 3 "~" H 5850 1700 50  0001 C CNN
	1    5850 1700
	1    0    0    -1  
$EndComp
Wire Wire Line
	5650 1950 5850 1950
Wire Wire Line
	5850 1950 5850 1850
$Comp
L power:VCC #PWR06
U 1 1 5F623102
P 5850 1250
F 0 "#PWR06" H 5850 1100 50  0001 C CNN
F 1 "VCC" H 5865 1423 50  0000 C CNN
F 2 "" H 5850 1250 50  0001 C CNN
F 3 "" H 5850 1250 50  0001 C CNN
	1    5850 1250
	1    0    0    -1  
$EndComp
Wire Wire Line
	5850 1250 5850 1400
$Comp
L Transistor_BJT:2SC1815 Q4
U 1 1 5F62310D
P 6250 1950
F 0 "Q4" H 6440 1996 50  0000 L CNN
F 1 "2SC1815" H 6440 1905 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 6450 1875 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 6250 1950 50  0001 L CNN
	1    6250 1950
	1    0    0    -1  
$EndComp
Wire Wire Line
	5850 1950 6050 1950
Connection ~ 5850 1950
$Comp
L Device:R R7
U 1 1 5F623119
P 6350 2450
F 0 "R7" H 6420 2496 50  0000 L CNN
F 1 "1k" H 6420 2405 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 6280 2450 50  0001 C CNN
F 3 "~" H 6350 2450 50  0001 C CNN
	1    6350 2450
	1    0    0    -1  
$EndComp
Wire Wire Line
	6350 2150 6350 2300
Wire Wire Line
	5850 1400 6350 1400
Wire Wire Line
	6350 1400 6350 1750
Connection ~ 5850 1400
Wire Wire Line
	5850 1400 5850 1550
$Comp
L Device:C C6
U 1 1 5F623128
P 6900 2150
F 0 "C6" V 6648 2150 50  0000 C CNN
F 1 "33uF" V 6739 2150 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D8.0mm_P5.00mm" H 6938 2000 50  0001 C CNN
F 3 "~" H 6900 2150 50  0001 C CNN
	1    6900 2150
	0    1    1    0   
$EndComp
Connection ~ 6350 2150
Wire Wire Line
	6350 2150 6750 2150
Wire Wire Line
	6350 1400 6700 1400
Wire Wire Line
	7050 1400 7050 1550
Connection ~ 6350 1400
Wire Wire Line
	7050 1850 7050 2150
$Comp
L Device:R R9
U 1 1 5F623138
P 7050 1700
F 0 "R9" H 7120 1746 50  0000 L CNN
F 1 "4.7k" H 7120 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 6980 1700 50  0001 C CNN
F 3 "~" H 7050 1700 50  0001 C CNN
	1    7050 1700
	1    0    0    -1  
$EndComp
$Comp
L Device:R R8
U 1 1 5F623142
P 6700 1700
F 0 "R8" H 6770 1746 50  0000 L CNN
F 1 "8.2k" H 6770 1655 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 6630 1700 50  0001 C CNN
F 3 "~" H 6700 1700 50  0001 C CNN
	1    6700 1700
	1    0    0    -1  
$EndComp
Wire Wire Line
	6700 1400 6700 1550
Connection ~ 6700 1400
Wire Wire Line
	6700 1400 7050 1400
$Comp
L Transistor_BJT:2SC1815 Q5
U 1 1 5F62314F
P 7350 2150
F 0 "Q5" H 7540 2196 50  0000 L CNN
F 1 "2SC1815" H 7540 2105 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 7550 2075 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 7350 2150 50  0001 L CNN
	1    7350 2150
	1    0    0    -1  
$EndComp
Wire Wire Line
	7050 2150 7150 2150
Connection ~ 7050 2150
Wire Wire Line
	7050 1400 7450 1400
Wire Wire Line
	7450 1400 7450 1950
Connection ~ 7050 1400
$Comp
L Transistor_BJT:2SC1815 Q6
U 1 1 5F62315E
P 7350 2650
F 0 "Q6" H 7540 2696 50  0000 L CNN
F 1 "2SC1815" H 7540 2605 50  0000 L CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 7550 2575 50  0001 L CIN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Toshiba%20PDFs/2SC1815.pdf" H 7350 2650 50  0001 L CNN
	1    7350 2650
	1    0    0    -1  
$EndComp
Wire Wire Line
	7450 2350 7450 2400
Wire Wire Line
	6700 1850 6700 2650
Wire Wire Line
	6700 2650 7150 2650
$Comp
L power:GND #PWR07
U 1 1 5F62316B
P 6350 2750
F 0 "#PWR07" H 6350 2500 50  0001 C CNN
F 1 "GND" H 6355 2577 50  0000 C CNN
F 2 "" H 6350 2750 50  0001 C CNN
F 3 "" H 6350 2750 50  0001 C CNN
	1    6350 2750
	1    0    0    -1  
$EndComp
Wire Wire Line
	6350 2600 6350 2750
$Comp
L Device:LED D2
U 1 1 5F623176
P 6700 2800
F 0 "D2" V 6739 2682 50  0000 R CNN
F 1 "LED" V 6648 2682 50  0000 R CNN
F 2 "LED_THT:LED_D3.0mm" H 6700 2800 50  0001 C CNN
F 3 "~" H 6700 2800 50  0001 C CNN
	1    6700 2800
	0    -1   -1   0   
$EndComp
Connection ~ 6700 2650
$Comp
L power:GND #PWR08
U 1 1 5F623181
P 6700 3050
F 0 "#PWR08" H 6700 2800 50  0001 C CNN
F 1 "GND" H 6705 2877 50  0000 C CNN
F 2 "" H 6700 3050 50  0001 C CNN
F 3 "" H 6700 3050 50  0001 C CNN
	1    6700 3050
	1    0    0    -1  
$EndComp
Wire Wire Line
	6700 3050 6700 2950
$Comp
L Device:R R10
U 1 1 5F62318C
P 7450 3100
F 0 "R10" H 7520 3146 50  0000 L CNN
F 1 "15" H 7520 3055 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7380 3100 50  0001 C CNN
F 3 "~" H 7450 3100 50  0001 C CNN
	1    7450 3100
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR09
U 1 1 5F623196
P 7450 3300
F 0 "#PWR09" H 7450 3050 50  0001 C CNN
F 1 "GND" H 7455 3127 50  0000 C CNN
F 2 "" H 7450 3300 50  0001 C CNN
F 3 "" H 7450 3300 50  0001 C CNN
	1    7450 3300
	1    0    0    -1  
$EndComp
Wire Wire Line
	7450 3250 7450 3300
Wire Wire Line
	7450 2950 7450 2850
$Comp
L Device:CP C8
U 1 1 5F6231A2
P 8000 2400
F 0 "C8" V 8255 2400 50  0000 C CNN
F 1 "1000uF" V 8164 2400 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 8038 2250 50  0001 C CNN
F 3 "~" H 8000 2400 50  0001 C CNN
	1    8000 2400
	0    -1   -1   0   
$EndComp
Wire Wire Line
	7450 2400 7850 2400
Connection ~ 7450 2400
Wire Wire Line
	7450 2400 7450 2450
$Comp
L Device:CP C7
U 1 1 5F6231AF
P 7800 1550
F 0 "C7" H 7918 1596 50  0000 L CNN
F 1 "2200uF" H 7918 1505 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 7838 1400 50  0001 C CNN
F 3 "~" H 7800 1550 50  0001 C CNN
	1    7800 1550
	1    0    0    -1  
$EndComp
Wire Wire Line
	7800 1400 7450 1400
Connection ~ 7450 1400
$Comp
L power:GND #PWR010
U 1 1 5F6231BB
P 7800 1800
F 0 "#PWR010" H 7800 1550 50  0001 C CNN
F 1 "GND" H 7805 1627 50  0000 C CNN
F 2 "" H 7800 1800 50  0001 C CNN
F 3 "" H 7800 1800 50  0001 C CNN
	1    7800 1800
	1    0    0    -1  
$EndComp
Wire Wire Line
	7800 1700 7800 1800
Text GLabel 8450 2400 2    50   Output ~ 0
OUT2
Wire Wire Line
	8150 2400 8450 2400
$Comp
L Connector:Barrel_Jack_Switch J1
U 1 1 5F641079
P 1950 4150
F 0 "J1" H 2007 4467 50  0000 C CNN
F 1 "Barrel_Jack_Switch" H 2007 4376 50  0000 C CNN
F 2 "Connector_BarrelJack:BarrelJack_Horizontal" H 2000 4110 50  0001 C CNN
F 3 "~" H 2000 4110 50  0001 C CNN
	1    1950 4150
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR012
U 1 1 5F641B6D
P 2650 4350
F 0 "#PWR012" H 2650 4100 50  0001 C CNN
F 1 "GND" H 2655 4177 50  0000 C CNN
F 2 "" H 2650 4350 50  0001 C CNN
F 3 "" H 2650 4350 50  0001 C CNN
	1    2650 4350
	1    0    0    -1  
$EndComp
Wire Wire Line
	2250 4150 2250 4250
Wire Wire Line
	2250 4250 2650 4250
Wire Wire Line
	2650 4250 2650 4350
Connection ~ 2250 4250
$Comp
L power:VCC #PWR011
U 1 1 5F6451EF
P 2650 3750
F 0 "#PWR011" H 2650 3600 50  0001 C CNN
F 1 "VCC" H 2665 3923 50  0000 C CNN
F 2 "" H 2650 3750 50  0001 C CNN
F 3 "" H 2650 3750 50  0001 C CNN
	1    2650 3750
	1    0    0    -1  
$EndComp
Wire Wire Line
	2250 4050 2650 4050
Wire Wire Line
	2650 4050 2650 3750
$Comp
L Connector:AudioJack3_SwitchTR J2
U 1 1 5F646F43
P 3700 4250
F 0 "J2" H 3682 4575 50  0000 C CNN
F 1 "AudioJack3_SwitchTR" H 3682 4484 50  0000 C CNN
F 2 "Connector_Audio:Jack_3.5mm_Ledino_KB3SPRS_Horizontal" H 3700 4250 50  0001 C CNN
F 3 "~" H 3700 4250 50  0001 C CNN
	1    3700 4250
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR013
U 1 1 5F647B74
P 4050 4700
F 0 "#PWR013" H 4050 4450 50  0001 C CNN
F 1 "GND" H 4055 4527 50  0000 C CNN
F 2 "" H 4050 4700 50  0001 C CNN
F 3 "" H 4050 4700 50  0001 C CNN
	1    4050 4700
	1    0    0    -1  
$EndComp
Wire Wire Line
	3900 4150 4050 4150
Wire Wire Line
	4050 4150 4050 4700
Wire Wire Line
	3900 4350 3900 4250
Text GLabel 4150 4250 2    50   Output ~ 0
IN2
Wire Wire Line
	3900 4250 4150 4250
Connection ~ 3900 4250
Text GLabel 4150 4450 2    50   Output ~ 0
IN1
Wire Wire Line
	3900 4450 4150 4450
Connection ~ 3900 4450
$Comp
L Connector:AudioJack3_SwitchTR J3
U 1 1 5F652530
P 5150 4250
F 0 "J3" H 5132 4575 50  0000 C CNN
F 1 "AudioJack3_SwitchTR" H 5132 4484 50  0000 C CNN
F 2 "Connector_Audio:Jack_3.5mm_Ledino_KB3SPRS_Horizontal" H 5150 4250 50  0001 C CNN
F 3 "~" H 5150 4250 50  0001 C CNN
	1    5150 4250
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR014
U 1 1 5F65253A
P 5500 4700
F 0 "#PWR014" H 5500 4450 50  0001 C CNN
F 1 "GND" H 5505 4527 50  0000 C CNN
F 2 "" H 5500 4700 50  0001 C CNN
F 3 "" H 5500 4700 50  0001 C CNN
	1    5500 4700
	1    0    0    -1  
$EndComp
Wire Wire Line
	5350 4150 5500 4150
Wire Wire Line
	5500 4150 5500 4700
Wire Wire Line
	5350 4350 5350 4250
Text GLabel 5600 4250 2    50   Input ~ 0
OUT2
Wire Wire Line
	5350 4250 5600 4250
Connection ~ 5350 4250
Wire Wire Line
	5350 4450 5600 4450
Connection ~ 5350 4450
Text GLabel 5600 4450 2    50   Input ~ 0
OUT1
Wire Wire Line
	5350 4450 5350 4550
Wire Wire Line
	3900 4450 3900 4550
$EndSCHEMATC
