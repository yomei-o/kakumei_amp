EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Device:C C3
U 1 1 5F5787B0
P 3450 2050
F 0 "C3" H 3335 2004 50  0000 R CNN
F 1 "2200pF" H 3335 2095 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D3.0mm_W1.6mm_P2.50mm" H 3488 1900 50  0001 C CNN
F 3 "~" H 3450 2050 50  0001 C CNN
	1    3450 2050
	-1   0    0    1   
$EndComp
$Comp
L power:VCC #PWR03
U 1 1 5F57AEF6
P 3950 850
F 0 "#PWR03" H 3950 700 50  0001 C CNN
F 1 "VCC" H 3965 1023 50  0000 C CNN
F 2 "" H 3950 850 50  0001 C CNN
F 3 "" H 3950 850 50  0001 C CNN
	1    3950 850 
	1    0    0    -1  
$EndComp
$Comp
L Device:C C7
U 1 1 5F57C369
P 4900 1000
F 0 "C7" H 4785 954 50  0000 R CNN
F 1 "0.1uF" H 4785 1045 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 4938 850 50  0001 C CNN
F 3 "~" H 4900 1000 50  0001 C CNN
	1    4900 1000
	-1   0    0    1   
$EndComp
$Comp
L Device:CP C4
U 1 1 5F57DB20
P 4350 1000
F 0 "C4" H 4468 1046 50  0000 L CNN
F 1 "1000uF" H 4468 955 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 4388 850 50  0001 C CNN
F 3 "~" H 4350 1000 50  0001 C CNN
	1    4350 1000
	1    0    0    -1  
$EndComp
NoConn ~ 4150 2350
Text GLabel 1950 1800 0    50   Input ~ 0
IN1
$Comp
L Device:C C6
U 1 1 5F5805C5
P 4850 2200
F 0 "C6" H 4735 2154 50  0000 R CNN
F 1 "0.1uF" H 4735 2245 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 4888 2050 50  0001 C CNN
F 3 "~" H 4850 2200 50  0001 C CNN
	1    4850 2200
	-1   0    0    1   
$EndComp
$Comp
L Device:R R4
U 1 1 5F580D0B
P 4850 2600
F 0 "R4" H 4780 2554 50  0000 R CNN
F 1 "10" H 4780 2645 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 4780 2600 50  0001 C CNN
F 3 "~" H 4850 2600 50  0001 C CNN
	1    4850 2600
	-1   0    0    1   
$EndComp
Wire Wire Line
	4850 2350 4850 2450
$Comp
L power:GND #PWR04
U 1 1 5F58168B
P 4850 2850
F 0 "#PWR04" H 4850 2600 50  0001 C CNN
F 1 "GND" H 4855 2677 50  0000 C CNN
F 2 "" H 4850 2850 50  0001 C CNN
F 3 "" H 4850 2850 50  0001 C CNN
	1    4850 2850
	1    0    0    -1  
$EndComp
Wire Wire Line
	4850 2750 4850 2850
$Comp
L Device:CP C8
U 1 1 5F581E9C
P 5200 2050
F 0 "C8" V 5455 2050 50  0000 C CNN
F 1 "470uF" V 5364 2050 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 5238 1900 50  0001 C CNN
F 3 "~" H 5200 2050 50  0001 C CNN
	1    5200 2050
	0    -1   -1   0   
$EndComp
Text GLabel 5900 2050 2    50   Output ~ 0
OUT1
$Comp
L Connector:Barrel_Jack_Switch J1
U 1 1 5F57F87E
P 7350 1400
F 0 "J1" H 7407 1717 50  0000 C CNN
F 1 "Barrel_Jack_Switch" H 7407 1626 50  0000 C CNN
F 2 "Connector_BarrelJack:BarrelJack_Horizontal" H 7400 1360 50  0001 C CNN
F 3 "~" H 7400 1360 50  0001 C CNN
	1    7350 1400
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR012
U 1 1 5F5806E3
P 7900 1650
F 0 "#PWR012" H 7900 1400 50  0001 C CNN
F 1 "GND" H 7905 1477 50  0000 C CNN
F 2 "" H 7900 1650 50  0001 C CNN
F 3 "" H 7900 1650 50  0001 C CNN
	1    7900 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	7650 1500 7650 1400
Wire Wire Line
	7650 1500 7900 1500
Wire Wire Line
	7900 1500 7900 1650
Connection ~ 7650 1500
$Comp
L power:VCC #PWR011
U 1 1 5F582FD6
P 7900 1200
F 0 "#PWR011" H 7900 1050 50  0001 C CNN
F 1 "VCC" H 7915 1373 50  0000 C CNN
F 2 "" H 7900 1200 50  0001 C CNN
F 3 "" H 7900 1200 50  0001 C CNN
	1    7900 1200
	1    0    0    -1  
$EndComp
Wire Wire Line
	7650 1300 7900 1300
Wire Wire Line
	7900 1300 7900 1200
$Comp
L Connector:AudioJack3_SwitchTR J2
U 1 1 5F58581D
P 7550 2550
F 0 "J2" H 7532 2875 50  0000 C CNN
F 1 "AudioJack3_SwitchTR" H 7532 2784 50  0000 C CNN
F 2 "Connector_Audio:Jack_3.5mm_Ledino_KB3SPRS_Horizontal" H 7550 2550 50  0001 C CNN
F 3 "~" H 7550 2550 50  0001 C CNN
	1    7550 2550
	1    0    0    -1  
$EndComp
Text GLabel 7950 2550 2    50   Output ~ 0
IN1
Wire Wire Line
	7750 2650 7750 2550
Wire Wire Line
	7950 2550 7750 2550
Connection ~ 7750 2550
Text GLabel 7950 2750 2    50   Output ~ 0
IN2
Wire Wire Line
	7750 2750 7950 2750
Wire Wire Line
	7750 2750 7750 2850
Connection ~ 7750 2750
$Comp
L power:GND #PWR0101
U 1 1 5F58C1FF
P 8350 2800
F 0 "#PWR0101" H 8350 2550 50  0001 C CNN
F 1 "GND" H 8355 2627 50  0000 C CNN
F 2 "" H 8350 2800 50  0001 C CNN
F 3 "" H 8350 2800 50  0001 C CNN
	1    8350 2800
	1    0    0    -1  
$EndComp
Wire Wire Line
	8350 2800 8350 2450
Wire Wire Line
	8350 2450 7750 2450
Wire Wire Line
	3950 850  4350 850 
Connection ~ 3950 850 
Connection ~ 4350 850 
Wire Wire Line
	4350 850  4900 850 
Wire Wire Line
	4900 1150 4350 1150
$Comp
L power:GND #PWR07
U 1 1 5F7ECF9B
P 4350 1250
F 0 "#PWR07" H 4350 1000 50  0001 C CNN
F 1 "GND" H 4355 1077 50  0000 C CNN
F 2 "" H 4350 1250 50  0001 C CNN
F 3 "" H 4350 1250 50  0001 C CNN
	1    4350 1250
	1    0    0    -1  
$EndComp
Wire Wire Line
	4350 1150 4350 1250
Connection ~ 4350 1150
$Comp
L Amplifier_Audio:LM386 U1
U 1 1 5F577324
P 4050 2050
F 0 "U1" H 4394 2096 50  0000 L CNN
F 1 "LM386" H 4394 2005 50  0000 L CNN
F 2 "Package_DIP:DIP-8_W7.62mm_Socket" H 4150 2150 50  0001 C CNN
F 3 "http://www.ti.com/lit/ds/symlink/lm386.pdf" H 4250 2250 50  0001 C CNN
	1    4050 2050
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C5
U 1 1 5F7F2AE6
P 4450 2500
F 0 "C5" H 4568 2546 50  0000 L CNN
F 1 "10uF" H 4568 2455 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D5.0mm_P2.50mm" H 4488 2350 50  0001 C CNN
F 3 "~" H 4450 2500 50  0001 C CNN
	1    4450 2500
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR08
U 1 1 5F7F3714
P 4450 2750
F 0 "#PWR08" H 4450 2500 50  0001 C CNN
F 1 "GND" H 4455 2577 50  0000 C CNN
F 2 "" H 4450 2750 50  0001 C CNN
F 3 "" H 4450 2750 50  0001 C CNN
	1    4450 2750
	1    0    0    -1  
$EndComp
Wire Wire Line
	4450 2750 4450 2650
Wire Wire Line
	4450 1750 4050 1750
Wire Wire Line
	4450 1750 4450 2350
$Comp
L power:GND #PWR06
U 1 1 5F7F4F01
P 3950 2550
F 0 "#PWR06" H 3950 2300 50  0001 C CNN
F 1 "GND" H 3955 2377 50  0000 C CNN
F 2 "" H 3950 2550 50  0001 C CNN
F 3 "" H 3950 2550 50  0001 C CNN
	1    3950 2550
	1    0    0    -1  
$EndComp
Wire Wire Line
	3950 2550 3950 2350
NoConn ~ 4050 2350
$Comp
L Device:R R5
U 1 1 5F7F618E
P 5650 2050
F 0 "R5" V 5443 2050 50  0000 C CNN
F 1 "4.7" V 5534 2050 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 5580 2050 50  0001 C CNN
F 3 "~" H 5650 2050 50  0001 C CNN
	1    5650 2050
	0    1    1    0   
$EndComp
Wire Wire Line
	5900 2050 5800 2050
Wire Wire Line
	5500 2050 5400 2050
Wire Wire Line
	5050 2050 4850 2050
Wire Wire Line
	4850 2050 4350 2050
Connection ~ 4850 2050
Wire Wire Line
	3950 850  3950 1750
$Comp
L Device:R R3
U 1 1 5F801A58
P 4700 1650
F 0 "R3" V 4493 1650 50  0000 C CNN
F 1 "10k" V 4584 1650 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 4630 1650 50  0001 C CNN
F 3 "~" H 4700 1650 50  0001 C CNN
	1    4700 1650
	0    1    1    0   
$EndComp
Wire Wire Line
	4850 1650 5400 1650
Wire Wire Line
	5400 1650 5400 2050
Connection ~ 5400 2050
Wire Wire Line
	5400 2050 5350 2050
$Comp
L Device:C C1
U 1 1 5F8062CD
P 3150 1800
F 0 "C1" H 3035 1754 50  0000 R CNN
F 1 "0.1uF" H 3035 1845 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 3188 1650 50  0001 C CNN
F 3 "~" H 3150 1800 50  0001 C CNN
	1    3150 1800
	0    1    1    0   
$EndComp
$Comp
L Device:C C2
U 1 1 5F806C39
P 3150 2300
F 0 "C2" H 3035 2254 50  0000 R CNN
F 1 "0.1uF" H 3035 2345 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 3188 2150 50  0001 C CNN
F 3 "~" H 3150 2300 50  0001 C CNN
	1    3150 2300
	0    1    1    0   
$EndComp
Wire Wire Line
	3300 1800 3450 1800
Wire Wire Line
	3750 1800 3750 1950
Wire Wire Line
	3750 2300 3450 2300
Wire Wire Line
	3750 2150 3750 2300
Connection ~ 3450 2300
Wire Wire Line
	3450 2300 3300 2300
Wire Wire Line
	3450 2200 3450 2300
Wire Wire Line
	3450 1900 3450 1800
Connection ~ 3450 1800
Wire Wire Line
	3450 1800 3750 1800
Wire Wire Line
	2900 1650 4550 1650
$Comp
L Device:R R2
U 1 1 5F80D997
P 2900 2600
F 0 "R2" H 2830 2554 50  0000 R CNN
F 1 "1k" H 2830 2645 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 2830 2600 50  0001 C CNN
F 3 "~" H 2900 2600 50  0001 C CNN
	1    2900 2600
	-1   0    0    1   
$EndComp
$Comp
L power:GND #PWR05
U 1 1 5F81016C
P 2900 2850
F 0 "#PWR05" H 2900 2600 50  0001 C CNN
F 1 "GND" H 2905 2677 50  0000 C CNN
F 2 "" H 2900 2850 50  0001 C CNN
F 3 "" H 2900 2850 50  0001 C CNN
	1    2900 2850
	1    0    0    -1  
$EndComp
Wire Wire Line
	2900 2750 2900 2850
$Comp
L Device:R R1
U 1 1 5F8112FC
P 2600 2200
F 0 "R1" H 2530 2154 50  0000 R CNN
F 1 "51k" H 2530 2245 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 2530 2200 50  0001 C CNN
F 3 "~" H 2600 2200 50  0001 C CNN
	1    2600 2200
	-1   0    0    1   
$EndComp
Wire Wire Line
	2600 1950 2600 2050
$Comp
L power:GND #PWR02
U 1 1 5F813A56
P 2600 2450
F 0 "#PWR02" H 2600 2200 50  0001 C CNN
F 1 "GND" H 2605 2277 50  0000 C CNN
F 2 "" H 2600 2450 50  0001 C CNN
F 3 "" H 2600 2450 50  0001 C CNN
	1    2600 2450
	1    0    0    -1  
$EndComp
Wire Wire Line
	2600 2350 2600 2450
$Comp
L Device:R_POT RV1
U 1 1 5F8163DA
P 2350 1950
F 0 "RV1" H 2280 1904 50  0000 R CNN
F 1 "10k" H 2280 1995 50  0000 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 2350 1950 50  0001 C CNN
F 3 "~" H 2350 1950 50  0001 C CNN
	1    2350 1950
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR01
U 1 1 5F7EA721
P 2350 2250
F 0 "#PWR01" H 2350 2000 50  0001 C CNN
F 1 "GND" H 2355 2077 50  0000 C CNN
F 2 "" H 2350 2250 50  0001 C CNN
F 3 "" H 2350 2250 50  0001 C CNN
	1    2350 2250
	1    0    0    -1  
$EndComp
Wire Wire Line
	2500 1950 2600 1950
Wire Wire Line
	1950 1800 2350 1800
Wire Wire Line
	2350 2100 2350 2250
$Comp
L Connector:AudioJack3_SwitchTR J3
U 1 1 5F7FF78F
P 7550 3600
F 0 "J3" H 7532 3925 50  0000 C CNN
F 1 "AudioJack3_SwitchTR" H 7532 3834 50  0000 C CNN
F 2 "Connector_Audio:Jack_3.5mm_Ledino_KB3SPRS_Horizontal" H 7550 3600 50  0001 C CNN
F 3 "~" H 7550 3600 50  0001 C CNN
	1    7550 3600
	1    0    0    -1  
$EndComp
Text GLabel 7950 3600 2    50   Input ~ 0
OUT1
Wire Wire Line
	7750 3700 7750 3600
Text GLabel 7950 3800 2    50   Input ~ 0
OUT2
Wire Wire Line
	7750 3800 7750 3900
$Comp
L power:GND #PWR09
U 1 1 5F7FF7A1
P 8350 3850
F 0 "#PWR09" H 8350 3600 50  0001 C CNN
F 1 "GND" H 8355 3677 50  0000 C CNN
F 2 "" H 8350 3850 50  0001 C CNN
F 3 "" H 8350 3850 50  0001 C CNN
	1    8350 3850
	1    0    0    -1  
$EndComp
Wire Wire Line
	8350 3850 8350 3500
Wire Wire Line
	8350 3500 7750 3500
Wire Wire Line
	7750 3600 7950 3600
Connection ~ 7750 3600
Wire Wire Line
	7750 3800 7950 3800
Connection ~ 7750 3800
$Comp
L Device:C C11
U 1 1 5F80B8B8
P 3500 4800
F 0 "C11" H 3385 4754 50  0000 R CNN
F 1 "2200pF" H 3385 4845 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D3.0mm_W1.6mm_P2.50mm" H 3538 4650 50  0001 C CNN
F 3 "~" H 3500 4800 50  0001 C CNN
	1    3500 4800
	-1   0    0    1   
$EndComp
$Comp
L power:VCC #PWR015
U 1 1 5F80B8C2
P 4000 3600
F 0 "#PWR015" H 4000 3450 50  0001 C CNN
F 1 "VCC" H 4015 3773 50  0000 C CNN
F 2 "" H 4000 3600 50  0001 C CNN
F 3 "" H 4000 3600 50  0001 C CNN
	1    4000 3600
	1    0    0    -1  
$EndComp
$Comp
L Device:C C15
U 1 1 5F80B8CC
P 4950 3750
F 0 "C15" H 4835 3704 50  0000 R CNN
F 1 "0.1uF" H 4835 3795 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 4988 3600 50  0001 C CNN
F 3 "~" H 4950 3750 50  0001 C CNN
	1    4950 3750
	-1   0    0    1   
$EndComp
$Comp
L Device:CP C12
U 1 1 5F80B8D6
P 4400 3750
F 0 "C12" H 4518 3796 50  0000 L CNN
F 1 "1000uF" H 4518 3705 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 4438 3600 50  0001 C CNN
F 3 "~" H 4400 3750 50  0001 C CNN
	1    4400 3750
	1    0    0    -1  
$EndComp
NoConn ~ 4200 5100
Text GLabel 2000 4550 0    50   Input ~ 0
IN2
$Comp
L Device:C C14
U 1 1 5F80B8E2
P 4900 4950
F 0 "C14" H 4785 4904 50  0000 R CNN
F 1 "0.1uF" H 4785 4995 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 4938 4800 50  0001 C CNN
F 3 "~" H 4900 4950 50  0001 C CNN
	1    4900 4950
	-1   0    0    1   
$EndComp
$Comp
L Device:R R9
U 1 1 5F80B8EC
P 4900 5350
F 0 "R9" H 4830 5304 50  0000 R CNN
F 1 "10" H 4830 5395 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 4830 5350 50  0001 C CNN
F 3 "~" H 4900 5350 50  0001 C CNN
	1    4900 5350
	-1   0    0    1   
$EndComp
Wire Wire Line
	4900 5100 4900 5200
$Comp
L power:GND #PWR019
U 1 1 5F80B8F7
P 4900 5600
F 0 "#PWR019" H 4900 5350 50  0001 C CNN
F 1 "GND" H 4905 5427 50  0000 C CNN
F 2 "" H 4900 5600 50  0001 C CNN
F 3 "" H 4900 5600 50  0001 C CNN
	1    4900 5600
	1    0    0    -1  
$EndComp
Wire Wire Line
	4900 5500 4900 5600
$Comp
L Device:CP C16
U 1 1 5F80B902
P 5250 4800
F 0 "C16" V 5505 4800 50  0000 C CNN
F 1 "470uF" V 5414 4800 50  0000 C CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 5288 4650 50  0001 C CNN
F 3 "~" H 5250 4800 50  0001 C CNN
	1    5250 4800
	0    -1   -1   0   
$EndComp
Text GLabel 5950 4800 2    50   Output ~ 0
OUT2
Wire Wire Line
	4000 3600 4400 3600
Connection ~ 4000 3600
Connection ~ 4400 3600
Wire Wire Line
	4400 3600 4950 3600
Wire Wire Line
	4950 3900 4400 3900
$Comp
L power:GND #PWR017
U 1 1 5F80B912
P 4400 4000
F 0 "#PWR017" H 4400 3750 50  0001 C CNN
F 1 "GND" H 4405 3827 50  0000 C CNN
F 2 "" H 4400 4000 50  0001 C CNN
F 3 "" H 4400 4000 50  0001 C CNN
	1    4400 4000
	1    0    0    -1  
$EndComp
Wire Wire Line
	4400 3900 4400 4000
Connection ~ 4400 3900
$Comp
L Amplifier_Audio:LM386 U2
U 1 1 5F80B91E
P 4100 4800
F 0 "U2" H 4444 4846 50  0000 L CNN
F 1 "LM386" H 4444 4755 50  0000 L CNN
F 2 "Package_DIP:DIP-8_W7.62mm_Socket" H 4200 4900 50  0001 C CNN
F 3 "http://www.ti.com/lit/ds/symlink/lm386.pdf" H 4300 5000 50  0001 C CNN
	1    4100 4800
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C13
U 1 1 5F80B928
P 4500 5250
F 0 "C13" H 4618 5296 50  0000 L CNN
F 1 "10uF" H 4618 5205 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D5.0mm_P2.50mm" H 4538 5100 50  0001 C CNN
F 3 "~" H 4500 5250 50  0001 C CNN
	1    4500 5250
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR018
U 1 1 5F80B932
P 4500 5500
F 0 "#PWR018" H 4500 5250 50  0001 C CNN
F 1 "GND" H 4505 5327 50  0000 C CNN
F 2 "" H 4500 5500 50  0001 C CNN
F 3 "" H 4500 5500 50  0001 C CNN
	1    4500 5500
	1    0    0    -1  
$EndComp
Wire Wire Line
	4500 5500 4500 5400
Wire Wire Line
	4500 4500 4100 4500
Wire Wire Line
	4500 4500 4500 5100
$Comp
L power:GND #PWR016
U 1 1 5F80B93F
P 4000 5300
F 0 "#PWR016" H 4000 5050 50  0001 C CNN
F 1 "GND" H 4005 5127 50  0000 C CNN
F 2 "" H 4000 5300 50  0001 C CNN
F 3 "" H 4000 5300 50  0001 C CNN
	1    4000 5300
	1    0    0    -1  
$EndComp
Wire Wire Line
	4000 5300 4000 5100
NoConn ~ 4100 5100
$Comp
L Device:R R10
U 1 1 5F80B94B
P 5700 4800
F 0 "R10" V 5493 4800 50  0000 C CNN
F 1 "4.7" V 5584 4800 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 5630 4800 50  0001 C CNN
F 3 "~" H 5700 4800 50  0001 C CNN
	1    5700 4800
	0    1    1    0   
$EndComp
Wire Wire Line
	5950 4800 5850 4800
Wire Wire Line
	5550 4800 5450 4800
Wire Wire Line
	5100 4800 4900 4800
Wire Wire Line
	4900 4800 4400 4800
Connection ~ 4900 4800
Wire Wire Line
	4000 3600 4000 4500
$Comp
L Device:R R8
U 1 1 5F80B95B
P 4750 4400
F 0 "R8" V 4543 4400 50  0000 C CNN
F 1 "10k" V 4634 4400 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 4680 4400 50  0001 C CNN
F 3 "~" H 4750 4400 50  0001 C CNN
	1    4750 4400
	0    1    1    0   
$EndComp
Wire Wire Line
	4900 4400 5450 4400
Wire Wire Line
	5450 4400 5450 4800
Connection ~ 5450 4800
Wire Wire Line
	5450 4800 5400 4800
$Comp
L Device:C C9
U 1 1 5F80B969
P 3200 4550
F 0 "C9" H 3085 4504 50  0000 R CNN
F 1 "0.1uF" H 3085 4595 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 3238 4400 50  0001 C CNN
F 3 "~" H 3200 4550 50  0001 C CNN
	1    3200 4550
	0    1    1    0   
$EndComp
$Comp
L Device:C C10
U 1 1 5F80B973
P 3200 5050
F 0 "C10" H 3085 5004 50  0000 R CNN
F 1 "0.1uF" H 3085 5095 50  0000 R CNN
F 2 "Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm" H 3238 4900 50  0001 C CNN
F 3 "~" H 3200 5050 50  0001 C CNN
	1    3200 5050
	0    1    1    0   
$EndComp
Wire Wire Line
	3350 4550 3500 4550
Wire Wire Line
	3800 4550 3800 4700
Wire Wire Line
	3800 5050 3500 5050
Wire Wire Line
	3800 4900 3800 5050
Connection ~ 3500 5050
Wire Wire Line
	3500 5050 3350 5050
Wire Wire Line
	3500 4950 3500 5050
Wire Wire Line
	3500 4650 3500 4550
Connection ~ 3500 4550
Wire Wire Line
	3500 4550 3800 4550
Wire Wire Line
	2950 4400 4600 4400
$Comp
L Device:R R7
U 1 1 5F80B989
P 2950 5350
F 0 "R7" H 2880 5304 50  0000 R CNN
F 1 "1k" H 2880 5395 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 2880 5350 50  0001 C CNN
F 3 "~" H 2950 5350 50  0001 C CNN
	1    2950 5350
	-1   0    0    1   
$EndComp
$Comp
L power:GND #PWR014
U 1 1 5F80B996
P 2950 5600
F 0 "#PWR014" H 2950 5350 50  0001 C CNN
F 1 "GND" H 2955 5427 50  0000 C CNN
F 2 "" H 2950 5600 50  0001 C CNN
F 3 "" H 2950 5600 50  0001 C CNN
	1    2950 5600
	1    0    0    -1  
$EndComp
Wire Wire Line
	2950 5500 2950 5600
$Comp
L Device:R R6
U 1 1 5F80B9A1
P 2650 4950
F 0 "R6" H 2580 4904 50  0000 R CNN
F 1 "51k" H 2580 4995 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0204_L3.6mm_D1.6mm_P7.62mm_Horizontal" V 2580 4950 50  0001 C CNN
F 3 "~" H 2650 4950 50  0001 C CNN
	1    2650 4950
	-1   0    0    1   
$EndComp
Wire Wire Line
	2650 4700 2650 4800
$Comp
L power:GND #PWR013
U 1 1 5F80B9AE
P 2650 5200
F 0 "#PWR013" H 2650 4950 50  0001 C CNN
F 1 "GND" H 2655 5027 50  0000 C CNN
F 2 "" H 2650 5200 50  0001 C CNN
F 3 "" H 2650 5200 50  0001 C CNN
	1    2650 5200
	1    0    0    -1  
$EndComp
Wire Wire Line
	2650 5100 2650 5200
$Comp
L Device:R_POT RV2
U 1 1 5F80B9B9
P 2400 4700
F 0 "RV2" H 2330 4654 50  0000 R CNN
F 1 "10k" H 2330 4745 50  0000 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 2400 4700 50  0001 C CNN
F 3 "~" H 2400 4700 50  0001 C CNN
	1    2400 4700
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR010
U 1 1 5F80B9C3
P 2400 5000
F 0 "#PWR010" H 2400 4750 50  0001 C CNN
F 1 "GND" H 2405 4827 50  0000 C CNN
F 2 "" H 2400 5000 50  0001 C CNN
F 3 "" H 2400 5000 50  0001 C CNN
	1    2400 5000
	1    0    0    -1  
$EndComp
Wire Wire Line
	2550 4700 2650 4700
Wire Wire Line
	2000 4550 2400 4550
Wire Wire Line
	2400 4850 2400 5000
Wire Wire Line
	3000 2300 2900 2300
Wire Wire Line
	2900 1650 2900 2300
Connection ~ 2900 2300
Wire Wire Line
	2900 2300 2900 2450
Wire Wire Line
	2600 1950 3000 1950
Wire Wire Line
	3000 1950 3000 1800
Connection ~ 2600 1950
Wire Wire Line
	2950 4400 2950 5050
Wire Wire Line
	3050 5050 2950 5050
Connection ~ 2950 5050
Wire Wire Line
	2950 5050 2950 5200
Wire Wire Line
	2650 4700 3050 4700
Wire Wire Line
	3050 4700 3050 4550
Connection ~ 2650 4700
$EndSCHEMATC
