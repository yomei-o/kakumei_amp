EESchema Schematic File Version 4
LIBS:SB1-01-MAIN-cache
EELAYER 26 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 1 1
Title "Schematic for SwitchBoard PCB"
Date "2019-05-24"
Rev "6A1.0A"
Comp "SenSprout Inc. "
Comment1 "Designed by A.Sasaki"
Comment2 "Model: SB1-01-MAIN-A"
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L CUI:PJ-002A J101
U 1 1 5CAD9047
P 10800 2850
F 0 "J101" H 10571 2900 50  0000 R CNN
F 1 "PJ-002A" H 10571 2809 50  0000 R CNN
F 2 "CUI:PJ-002A" H 10850 2810 50  0001 C CNN
F 3 "https://www.cui.com/product/resource/digikeypdf/pj-002a.pdf" H 10850 2810 50  0001 C CNN
F 4 "CUI Inc." H 10900 3160 50  0001 C CNN "Manufacturer"
F 5 "PJ-002A" H 11000 3260 50  0001 C CNN "Manufacturer Part Number"
	1    10800 2850
	-1   0    0    -1  
$EndComp
Wire Wire Line
	6400 2750 7200 2750
Wire Wire Line
	6400 2850 9800 2850
Wire Wire Line
	10300 2850 10300 2950
Wire Wire Line
	10300 2950 10500 2950
Connection ~ 10300 2950
Wire Wire Line
	10300 2750 10300 2650
Connection ~ 10300 2750
Wire Wire Line
	10300 2750 10500 2750
$Comp
L power:+24V #PWR0101
U 1 1 5CAD9690
P 10300 2650
F 0 "#PWR0101" H 10300 2500 50  0001 C CNN
F 1 "+24V" H 10315 2823 50  0000 C CNN
F 2 "" H 10300 2650 50  0001 C CNN
F 3 "" H 10300 2650 50  0001 C CNN
	1    10300 2650
	1    0    0    -1  
$EndComp
Text Notes 11500 3250 0    50   ~ 0
DC24V Input
$Comp
L NKK:M-2022NB SW101
U 1 1 5CAD9732
P 7700 3850
F 0 "SW101" H 7675 4125 50  0000 C CNN
F 1 "M-2022NB" H 7675 4034 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 3850 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 3850 50  0001 C CNN
F 4 "NKK" H 7800 4200 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 4300 50  0001 C CNN "Manufacturer Part Number"
	1    7700 3850
	1    0    0    -1  
$EndComp
$Comp
L optosupply:OSR5JA5E34B D102
U 1 1 5CAD9959
P 9000 4250
F 0 "D102" H 9000 4495 50  0000 C CNN
F 1 "OSR5JA5E34B" H 9000 4404 50  0000 C CNN
F 2 "LED_THT:LED_D5.0mm" H 8900 4250 60  0001 C CNN
F 3 "http://akizukidenshi.com/download/OSR5JA5E34B.pdf" H 9000 4350 60  0001 C CNN
F 4 "OptoSupply" H 9100 4430 50  0001 C CNN "Manufacturer"
F 5 "OSR5JA5E34B" H 9200 4530 50  0001 C CNN "Manufacturer Part Number"
	1    9000 4250
	1    0    0    -1  
$EndComp
$Comp
L semitech:E-562 D101
U 1 1 5CAD9B86
P 8500 4250
F 0 "D101" H 8500 4060 50  0000 C CNN
F 1 "E-562" H 8500 4151 50  0000 C CNN
F 2 "Diodes_THT:D_DO-35_SOD27_P7.62mm_Horizontal" H 8400 4300 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/typeE.pdf" H 8500 4400 50  0001 C CNN
F 4 "SEMITEC" H 8600 4500 50  0001 C CNN "Manufacturer"
F 5 "E-562" H 8700 4600 50  0001 C CNN "Manufacturer Part Number"
	1    8500 4250
	-1   0    0    1   
$EndComp
Wire Wire Line
	8600 4250 8800 4250
Wire Wire Line
	8400 4250 8300 4250
Wire Wire Line
	8300 4250 8300 3850
Wire Wire Line
	8300 3850 7850 3850
Wire Wire Line
	8300 3850 9450 3850
Connection ~ 8300 3850
Wire Wire Line
	9200 4250 9450 4250
Connection ~ 10300 4250
Wire Wire Line
	7500 3800 7200 3800
Wire Wire Line
	7200 3800 7200 2750
Connection ~ 7200 2750
Wire Wire Line
	7200 2750 9800 2750
Wire Wire Line
	6400 3900 7400 3900
$Comp
L NKK:M-2022NB SW102
U 1 1 5CADACAD
P 7700 5300
F 0 "SW102" H 7675 5575 50  0000 C CNN
F 1 "M-2022NB" H 7675 5484 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 5300 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 5300 50  0001 C CNN
F 4 "NKK" H 7800 5650 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 5750 50  0001 C CNN "Manufacturer Part Number"
	1    7700 5300
	1    0    0    -1  
$EndComp
$Comp
L optosupply:OSR5JA5E34B D104
U 1 1 5CADACB5
P 9000 5700
F 0 "D104" H 9000 5945 50  0000 C CNN
F 1 "OSR5JA5E34B" H 9000 5854 50  0000 C CNN
F 2 "LED_THT:LED_D5.0mm" H 8900 5700 60  0001 C CNN
F 3 "http://akizukidenshi.com/download/OSR5JA5E34B.pdf" H 9000 5800 60  0001 C CNN
F 4 "OptoSupply" H 9100 5880 50  0001 C CNN "Manufacturer"
F 5 "OSR5JA5E34B" H 9200 5980 50  0001 C CNN "Manufacturer Part Number"
	1    9000 5700
	1    0    0    -1  
$EndComp
$Comp
L semitech:E-562 D103
U 1 1 5CADACBD
P 8500 5700
F 0 "D103" H 8500 5510 50  0000 C CNN
F 1 "E-562" H 8500 5601 50  0000 C CNN
F 2 "Diodes_THT:D_DO-35_SOD27_P7.62mm_Horizontal" H 8400 5750 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/typeE.pdf" H 8500 5850 50  0001 C CNN
F 4 "SEMITEC" H 8600 5950 50  0001 C CNN "Manufacturer"
F 5 "E-562" H 8700 6050 50  0001 C CNN "Manufacturer Part Number"
	1    8500 5700
	-1   0    0    1   
$EndComp
Wire Wire Line
	8600 5700 8800 5700
Wire Wire Line
	8400 5700 8300 5700
Wire Wire Line
	8300 5700 8300 5300
Wire Wire Line
	8300 5300 7850 5300
Wire Wire Line
	8300 5300 9450 5300
Connection ~ 8300 5300
Wire Wire Line
	10300 5400 10300 5700
Wire Wire Line
	9200 5700 9450 5700
Connection ~ 10300 5700
Wire Wire Line
	7500 5250 7200 5250
Wire Wire Line
	7200 5250 7200 4200
Connection ~ 7200 3800
$Comp
L NKK:M-2022NB SW103
U 1 1 5CADB2C2
P 7700 6750
F 0 "SW103" H 7675 7025 50  0000 C CNN
F 1 "M-2022NB" H 7675 6934 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 6750 50  0001 C CNN
F 3 "" H 7500 6750 50  0001 C CNN
F 4 "NKK" H 7800 7100 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 7200 50  0001 C CNN "Manufacturer Part Number"
	1    7700 6750
	1    0    0    -1  
$EndComp
$Comp
L optosupply:OSR5JA5E34B D106
U 1 1 5CADB2CA
P 9000 7150
F 0 "D106" H 9000 7395 50  0000 C CNN
F 1 "OSR5JA5E34B" H 9000 7304 50  0000 C CNN
F 2 "LED_THT:LED_D5.0mm" H 8900 7150 60  0001 C CNN
F 3 "http://akizukidenshi.com/download/OSR5JA5E34B.pdf" H 9000 7250 60  0001 C CNN
F 4 "OptoSupply" H 9100 7330 50  0001 C CNN "Manufacturer"
F 5 "OSR5JA5E34B" H 9200 7430 50  0001 C CNN "Manufacturer Part Number"
	1    9000 7150
	1    0    0    -1  
$EndComp
$Comp
L semitech:E-562 D105
U 1 1 5CADB2D2
P 8500 7150
F 0 "D105" H 8500 6960 50  0000 C CNN
F 1 "E-562" H 8500 7051 50  0000 C CNN
F 2 "Diodes_THT:D_DO-35_SOD27_P7.62mm_Horizontal" H 8400 7200 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/typeE.pdf" H 8500 7300 50  0001 C CNN
F 4 "SEMITEC" H 8600 7400 50  0001 C CNN "Manufacturer"
F 5 "E-562" H 8700 7500 50  0001 C CNN "Manufacturer Part Number"
	1    8500 7150
	-1   0    0    1   
$EndComp
Wire Wire Line
	8600 7150 8800 7150
Wire Wire Line
	8400 7150 8300 7150
Wire Wire Line
	8300 7150 8300 6750
Wire Wire Line
	8300 6750 7850 6750
Wire Wire Line
	8300 6750 9450 6750
Connection ~ 8300 6750
Wire Wire Line
	10300 6850 10300 7150
Wire Wire Line
	9200 7150 9450 7150
Connection ~ 10300 7150
Wire Wire Line
	7500 6700 7200 6700
Wire Wire Line
	7200 6700 7200 5650
$Comp
L NKK:M-2022NB SW104
U 1 1 5CADB2F0
P 7700 8200
F 0 "SW104" H 7675 8475 50  0000 C CNN
F 1 "M-2022NB" H 7675 8384 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 8200 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 8200 50  0001 C CNN
F 4 "NKK" H 7800 8550 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 8650 50  0001 C CNN "Manufacturer Part Number"
	1    7700 8200
	1    0    0    -1  
$EndComp
$Comp
L optosupply:OSR5JA5E34B D108
U 1 1 5CADB2F8
P 9000 8600
F 0 "D108" H 9000 8845 50  0000 C CNN
F 1 "OSR5JA5E34B" H 9000 8754 50  0000 C CNN
F 2 "LED_THT:LED_D5.0mm" H 8900 8600 60  0001 C CNN
F 3 "http://akizukidenshi.com/download/OSR5JA5E34B.pdf" H 9000 8700 60  0001 C CNN
F 4 "OptoSupply" H 9100 8780 50  0001 C CNN "Manufacturer"
F 5 "OSR5JA5E34B" H 9200 8880 50  0001 C CNN "Manufacturer Part Number"
	1    9000 8600
	1    0    0    -1  
$EndComp
$Comp
L semitech:E-562 D107
U 1 1 5CADB300
P 8500 8600
F 0 "D107" H 8500 8410 50  0000 C CNN
F 1 "E-562" H 8500 8501 50  0000 C CNN
F 2 "Diodes_THT:D_DO-35_SOD27_P7.62mm_Horizontal" H 8400 8650 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/typeE.pdf" H 8500 8750 50  0001 C CNN
F 4 "SEMITEC" H 8600 8850 50  0001 C CNN "Manufacturer"
F 5 "E-562" H 8700 8950 50  0001 C CNN "Manufacturer Part Number"
	1    8500 8600
	-1   0    0    1   
$EndComp
Wire Wire Line
	8600 8600 8800 8600
Wire Wire Line
	8400 8600 8300 8600
Wire Wire Line
	8300 8600 8300 8200
Wire Wire Line
	8300 8200 7850 8200
Wire Wire Line
	8300 8200 9450 8200
Connection ~ 8300 8200
Wire Wire Line
	9200 8600 9450 8600
Connection ~ 10300 8600
Wire Wire Line
	10300 8600 10300 8750
Wire Wire Line
	7500 8150 7200 8150
Wire Wire Line
	7200 8150 7200 7100
Connection ~ 7200 6700
Connection ~ 7200 5250
Wire Wire Line
	6400 4000 7100 4000
Wire Wire Line
	7100 4000 7100 5350
Wire Wire Line
	7100 5350 7400 5350
Wire Wire Line
	6400 4100 7000 4100
Wire Wire Line
	7000 4100 7000 6800
Wire Wire Line
	7000 6800 7400 6800
Wire Wire Line
	6400 4200 6900 4200
Wire Wire Line
	6900 4200 6900 8250
Wire Wire Line
	6900 8250 7400 8250
$Comp
L NKK:M-2022NB SW101
U 2 1 5CAE8291
P 7750 4250
F 0 "SW101" H 7725 4525 50  0000 C CNN
F 1 "M-2022NB" H 7725 4434 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7550 4250 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7550 4250 50  0001 C CNN
F 4 "NKK" H 7850 4600 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7950 4700 50  0001 C CNN "Manufacturer Part Number"
	2    7750 4250
	1    0    0    -1  
$EndComp
Wire Wire Line
	7550 4200 7200 4200
Connection ~ 7200 4200
Wire Wire Line
	7200 4200 7200 3800
Wire Wire Line
	7550 4300 7400 4300
Wire Wire Line
	7400 4300 7400 3900
Connection ~ 7400 3900
Wire Wire Line
	7400 3900 7500 3900
Wire Wire Line
	7900 4250 8300 4250
Connection ~ 8300 4250
$Comp
L NKK:M-2022NB SW102
U 2 1 5CAEC3B8
P 7750 5700
F 0 "SW102" H 7725 5975 50  0000 C CNN
F 1 "M-2022NB" H 7725 5884 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7550 5700 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7550 5700 50  0001 C CNN
F 4 "NKK" H 7850 6050 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7950 6150 50  0001 C CNN "Manufacturer Part Number"
	2    7750 5700
	1    0    0    -1  
$EndComp
$Comp
L NKK:M-2022NB SW103
U 2 1 5CAEC506
P 7700 7150
F 0 "SW103" H 7675 7425 50  0000 C CNN
F 1 "M-2022NB" H 7675 7334 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 7150 50  0001 C CNN
F 3 "" H 7500 7150 50  0001 C CNN
F 4 "NKK" H 7800 7500 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 7600 50  0001 C CNN "Manufacturer Part Number"
	2    7700 7150
	1    0    0    -1  
$EndComp
$Comp
L NKK:M-2022NB SW104
U 2 1 5CAEC556
P 7700 8600
F 0 "SW104" H 7675 8875 50  0000 C CNN
F 1 "M-2022NB" H 7675 8784 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 8600 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 8600 50  0001 C CNN
F 4 "NKK" H 7800 8950 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 9050 50  0001 C CNN "Manufacturer Part Number"
	2    7700 8600
	1    0    0    -1  
$EndComp
Wire Wire Line
	7850 8600 8300 8600
Connection ~ 8300 8600
Wire Wire Line
	7500 8550 7200 8550
Wire Wire Line
	7200 8550 7200 8150
Connection ~ 7200 8150
Wire Wire Line
	7500 8650 7400 8650
Wire Wire Line
	7400 8650 7400 8250
Connection ~ 7400 8250
Wire Wire Line
	7400 8250 7500 8250
Wire Wire Line
	7500 7200 7400 7200
Wire Wire Line
	7400 7200 7400 6800
Connection ~ 7400 6800
Wire Wire Line
	7400 6800 7500 6800
Wire Wire Line
	7500 7100 7200 7100
Connection ~ 7200 7100
Wire Wire Line
	7200 7100 7200 6700
Wire Wire Line
	7550 5650 7200 5650
Connection ~ 7200 5650
Wire Wire Line
	7200 5650 7200 5250
Wire Wire Line
	7550 5750 7400 5750
Wire Wire Line
	7400 5750 7400 5350
Connection ~ 7400 5350
Wire Wire Line
	7400 5350 7500 5350
Wire Wire Line
	10300 5700 10300 6850
Connection ~ 10300 6850
Wire Wire Line
	10300 4250 10300 5400
Connection ~ 10300 5400
$Comp
L power:GND #PWR0102
U 1 1 5CAFFD0C
P 10300 8750
F 0 "#PWR0102" H 10300 8500 50  0001 C CNN
F 1 "GND" H 10305 8577 50  0000 C CNN
F 2 "" H 10300 8750 50  0001 C CNN
F 3 "" H 10300 8750 50  0001 C CNN
	1    10300 8750
	1    0    0    -1  
$EndComp
Text Notes 5450 3250 0    50   ~ 0
DC24V Output\nTo Gateway PCB
Text Notes 5250 4550 0    50   ~ 0
Solenoid Valve\nControl Input
Text Notes 11700 6000 0    50   ~ 0
Solenoid Valve\nControl Output
Wire Notes Line
	7300 3500 7300 4800
Wire Notes Line
	7300 4800 8000 4800
Wire Notes Line
	8000 4800 8000 3500
Wire Notes Line
	8000 3500 7300 3500
Wire Wire Line
	7900 5700 8300 5700
Connection ~ 8300 5700
Wire Wire Line
	7850 7150 8300 7150
Connection ~ 8300 7150
Wire Notes Line
	8000 6250 8000 4950
Wire Notes Line
	8000 4950 7300 4950
Wire Notes Line
	8000 7700 8000 6400
Wire Notes Line
	8000 6400 7300 6400
Wire Notes Line
	8000 9150 8000 7850
Wire Notes Line
	8000 7850 7300 7850
Wire Notes Line
	7300 7850 7300 9150
Wire Notes Line
	7300 9150 8000 9150
Wire Notes Line
	7300 6400 7300 7700
Wire Notes Line
	7300 7700 8000 7700
Wire Notes Line
	7300 4950 7300 6250
Wire Notes Line
	7300 6250 8000 6250
Text Notes 7450 3450 0    50   ~ 0
DPDT Rocker Switch
Wire Wire Line
	10500 2850 10300 2850
Connection ~ 10300 2850
Text Notes 8350 4400 0    50   ~ 0
CRD: 5.6mA
$Comp
L semitech:Z2033 D109
U 1 1 5CDA635A
P 9950 4050
F 0 "D109" V 9904 4113 50  0000 L CNN
F 1 "Z2033" V 9995 4113 50  0000 L CNN
F 2 "Diodes_THT:D_DO-15_P10.16mm_Horizontal" H 9850 4100 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/souhoukou-vrd_97H.pdf" H 9950 4200 50  0001 C CNN
F 4 "SEMITEC" H 10050 4300 50  0001 C CNN "Manufacturer"
F 5 "Z2033" H 10150 4400 50  0001 C CNN "Manufacturer Part Number"
	1    9950 4050
	0    1    1    0   
$EndComp
Wire Wire Line
	9950 3950 9950 3850
Connection ~ 9950 3850
Wire Wire Line
	9950 4150 9950 4250
Connection ~ 9950 4250
Wire Wire Line
	9950 4250 10300 4250
Wire Wire Line
	9950 5400 9950 5300
Wire Wire Line
	9950 5600 9950 5700
Connection ~ 9950 5300
Connection ~ 9950 5700
Wire Wire Line
	9950 5700 10300 5700
Wire Wire Line
	9950 6850 9950 6750
Wire Wire Line
	9950 7050 9950 7150
Connection ~ 9950 6750
Connection ~ 9950 7150
Wire Wire Line
	9950 7150 10300 7150
Wire Wire Line
	9950 8300 9950 8200
Wire Wire Line
	9950 8500 9950 8600
Connection ~ 9950 8200
Connection ~ 9950 8600
Wire Wire Line
	9950 8600 10300 8600
$Comp
L murata:RDEC71H226MWK1H03B C101
U 1 1 5CDBC3B8
P 9450 4050
F 0 "C101" V 9399 4103 40  0000 L CNN
F 1 "22u/50(X7S)" V 9475 4103 40  0000 L CNN
F 2 "murata:RDEXXXXXXXXXWK1XXXX" H 9550 4075 10  0001 C CNN
F 3 "http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.ashx" H 9450 4050 10  0001 C CNN
F 4 "RADIAL" V 9526 4103 10  0000 L CNN "Size"
F 5 "Murata Electronics" H 9650 4350 50  0001 C CNN "Manufacturer"
F 6 "RDEC71H226MWK1H03B" H 9750 4450 50  0001 C CNN "Manufacturer Part Number"
	1    9450 4050
	0    1    1    0   
$EndComp
$Comp
L semitech:Z2033 D110
U 1 1 5CDBC7E8
P 9950 5500
F 0 "D110" V 9904 5563 50  0000 L CNN
F 1 "Z2033" V 9995 5563 50  0000 L CNN
F 2 "Diodes_THT:D_DO-15_P10.16mm_Horizontal" H 9850 5550 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/souhoukou-vrd_97H.pdf" H 9950 5650 50  0001 C CNN
F 4 "SEMITEC" H 10050 5750 50  0001 C CNN "Manufacturer"
F 5 "Z2033" H 10150 5850 50  0001 C CNN "Manufacturer Part Number"
	1    9950 5500
	0    1    1    0   
$EndComp
$Comp
L semitech:Z2033 D111
U 1 1 5CDBC842
P 9950 6950
F 0 "D111" V 9904 7013 50  0000 L CNN
F 1 "Z2033" V 9995 7013 50  0000 L CNN
F 2 "Diodes_THT:D_DO-15_P10.16mm_Horizontal" H 9850 7000 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/souhoukou-vrd_97H.pdf" H 9950 7100 50  0001 C CNN
F 4 "SEMITEC" H 10050 7200 50  0001 C CNN "Manufacturer"
F 5 "Z2033" H 10150 7300 50  0001 C CNN "Manufacturer Part Number"
	1    9950 6950
	0    1    1    0   
$EndComp
$Comp
L semitech:Z2033 D112
U 1 1 5CDBC89E
P 9950 8400
F 0 "D112" V 9904 8463 50  0000 L CNN
F 1 "Z2033" V 9995 8463 50  0000 L CNN
F 2 "Diodes_THT:D_DO-15_P10.16mm_Horizontal" H 9850 8450 50  0001 C CNN
F 3 "http://www.semitec.co.jp/uploads/souhoukou-vrd_97H.pdf" H 9950 8550 50  0001 C CNN
F 4 "SEMITEC" H 10050 8650 50  0001 C CNN "Manufacturer"
F 5 "Z2033" H 10150 8750 50  0001 C CNN "Manufacturer Part Number"
	1    9950 8400
	0    1    1    0   
$EndComp
Wire Wire Line
	9450 4000 9450 3850
Connection ~ 9450 3850
Wire Wire Line
	9450 3850 9950 3850
Wire Wire Line
	9450 4100 9450 4250
Connection ~ 9450 4250
Wire Wire Line
	9450 4250 9950 4250
$Comp
L murata:RDEC71H226MWK1H03B C102
U 1 1 5CDC625D
P 9450 5500
F 0 "C102" V 9399 5553 40  0000 L CNN
F 1 "22u/50(X7S)" V 9475 5553 40  0000 L CNN
F 2 "murata:RDEXXXXXXXXXWK1XXXX" H 9550 5525 10  0001 C CNN
F 3 "http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.ashx" H 9450 5500 10  0001 C CNN
F 4 "RADIAL" V 9526 5553 10  0000 L CNN "Size"
F 5 "Murata Electronics" H 9650 5800 50  0001 C CNN "Manufacturer"
F 6 "RDEC71H226MWK1H03B" H 9750 5900 50  0001 C CNN "Manufacturer Part Number"
	1    9450 5500
	0    1    1    0   
$EndComp
Wire Wire Line
	9450 5450 9450 5300
Wire Wire Line
	9450 5550 9450 5700
Connection ~ 9450 5300
Wire Wire Line
	9450 5300 9950 5300
Connection ~ 9450 5700
Wire Wire Line
	9450 5700 9950 5700
$Comp
L murata:RDEC71H226MWK1H03B C103
U 1 1 5CDC99AC
P 9450 6950
F 0 "C103" V 9399 7003 40  0000 L CNN
F 1 "22u/50(X7S)" V 9475 7003 40  0000 L CNN
F 2 "murata:RDEXXXXXXXXXWK1XXXX" H 9550 6975 10  0001 C CNN
F 3 "http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.ashx" H 9450 6950 10  0001 C CNN
F 4 "RADIAL" V 9526 7003 10  0000 L CNN "Size"
F 5 "Murata Electronics" H 9650 7250 50  0001 C CNN "Manufacturer"
F 6 "RDEC71H226MWK1H03B" H 9750 7350 50  0001 C CNN "Manufacturer Part Number"
	1    9450 6950
	0    1    1    0   
$EndComp
Wire Wire Line
	9450 6900 9450 6750
Wire Wire Line
	9450 7000 9450 7150
Connection ~ 9450 6750
Wire Wire Line
	9450 6750 9950 6750
Connection ~ 9450 7150
Wire Wire Line
	9450 7150 9950 7150
$Comp
L murata:RDEC71H226MWK1H03B C104
U 1 1 5CDCD45E
P 9450 8400
F 0 "C104" V 9399 8453 40  0000 L CNN
F 1 "22u/50(X7S)" V 9475 8453 40  0000 L CNN
F 2 "murata:RDEXXXXXXXXXWK1XXXX" H 9550 8425 10  0001 C CNN
F 3 "http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.ashx" H 9450 8400 10  0001 C CNN
F 4 "RADIAL" V 9526 8453 10  0000 L CNN "Size"
F 5 "Murata Electronics" H 9650 8700 50  0001 C CNN "Manufacturer"
F 6 "RDEC71H226MWK1H03B" H 9750 8800 50  0001 C CNN "Manufacturer Part Number"
	1    9450 8400
	0    1    1    0   
$EndComp
Wire Wire Line
	9450 8350 9450 8200
Wire Wire Line
	9450 8450 9450 8600
Connection ~ 9450 8200
Wire Wire Line
	9450 8200 9950 8200
Connection ~ 9450 8600
Wire Wire Line
	9450 8600 9950 8600
Wire Notes Line
	10750 8450 11650 8450
Wire Notes Line
	11650 8450 11650 3700
Wire Notes Line
	11650 3700 10750 3700
Text Notes 8350 5850 0    50   ~ 0
CRD: 5.6mA
Text Notes 8350 6900 0    50   ~ 0
CRD: 5.6mA
Text Notes 8350 7950 0    50   ~ 0
CRD: 5.6mA
$Comp
L satoparts:ML-40-S1BYF-6P CN101
U 1 1 5CE1601A
P 11300 5850
F 0 "CN101" H 11150 6400 50  0000 L CNN
F 1 "ML-40-S1BYF-6P" H 10800 6200 50  0000 L CNN
F 2 "satoparts:ML-40-S1BYF-6P_2" H 11400 6300 50  0001 C CNN
F 3 "http://www.satoparts.co.jp/JPN/item/ML/ML-40-S1BYF/" H 11300 6000 50  0001 C CNN
F 4 "SATO PARTS CO.,LTD." H 11400 6300 50  0001 C CNN "Manufacturer"
F 5 "ML-40-S1BYF-6P" H 11500 6400 50  0001 C CNN "Manufacturer Part Number"
	1    11300 5850
	1    0    0    -1  
$EndComp
Wire Wire Line
	11100 5600 10750 5600
Wire Wire Line
	10750 5600 10750 3850
Wire Wire Line
	9950 3850 10750 3850
Wire Wire Line
	10300 2950 10300 4250
Wire Wire Line
	10300 7150 10300 8600
Wire Wire Line
	10650 5400 10650 5700
Wire Wire Line
	10650 5700 11100 5700
Wire Wire Line
	10300 5400 10650 5400
Wire Wire Line
	11100 5800 10550 5800
Wire Wire Line
	10550 5800 10550 5300
Wire Wire Line
	9950 5300 10550 5300
Wire Wire Line
	11100 5900 10750 5900
Wire Wire Line
	10750 5900 10750 6750
Wire Wire Line
	9950 6750 10750 6750
Wire Wire Line
	10850 6850 10850 6000
Wire Wire Line
	10850 6000 11100 6000
Wire Wire Line
	10300 6850 10850 6850
Wire Wire Line
	11100 6100 10950 6100
Wire Wire Line
	10950 6100 10950 8200
Wire Wire Line
	9950 8200 10950 8200
$Comp
L Alphaplus:TB111-2-2-U-1-1 J102
U 1 1 5CE2E2AF
P 6200 2800
F 0 "J102" H 6120 3067 50  0000 C CNN
F 1 "TB111-2-2-U-1-1" H 6120 2976 50  0000 C CNN
F 2 "Alphaplus:TB111-2-2-x-x-x" H 6200 2750 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/alphaplus/TB111-2-x-x-x-x.pdf" H 6200 2750 50  0001 C CNN
F 4 "Alphaplus Connectors & Cables Corp." H 6300 3050 50  0001 C CNN "Manufacturer"
F 5 "TB111-2-2-U-1-1" H 6400 3150 50  0001 C CNN "Manufacturer Part Number"
	1    6200 2800
	-1   0    0    -1  
$EndComp
$Comp
L Alphaplus:TB111-2-2-U-1-1 J103
U 1 1 5CE32695
P 6200 3950
F 0 "J103" H 6120 3675 50  0000 C CNN
F 1 "TB111-2-2-U-1-1" H 6120 3766 50  0000 C CNN
F 2 "Alphaplus:TB111-2-2-x-x-x" H 6200 3900 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/alphaplus/TB111-2-x-x-x-x.pdf" H 6200 3900 50  0001 C CNN
F 4 "Alphaplus Connectors & Cables Corp." H 6300 4200 50  0001 C CNN "Manufacturer"
F 5 "TB111-2-2-U-1-1" H 6400 4300 50  0001 C CNN "Manufacturer Part Number"
	1    6200 3950
	-1   0    0    1   
$EndComp
$Comp
L Alphaplus:TB111-2-2-U-1-1 J104
U 1 1 5CE32701
P 6200 4150
F 0 "J104" H 6200 4300 50  0000 C CNN
F 1 "TB111-2-2-U-1-1" H 6200 4400 50  0000 C CNN
F 2 "Alphaplus:TB111-2-2-x-x-x" H 6200 4100 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/alphaplus/TB111-2-x-x-x-x.pdf" H 6200 4100 50  0001 C CNN
F 4 "Alphaplus Connectors & Cables Corp." H 6300 4400 50  0001 C CNN "Manufacturer"
F 5 "TB111-2-2-U-1-1" H 6400 4500 50  0001 C CNN "Manufacturer Part Number"
	1    6200 4150
	-1   0    0    1   
$EndComp
$Comp
L power:PWR_FLAG #FLG0101
U 1 1 5CE5919D
P 9800 2750
F 0 "#FLG0101" H 9800 2825 50  0001 C CNN
F 1 "PWR_FLAG" H 9800 2924 50  0001 C CNN
F 2 "" H 9800 2750 50  0001 C CNN
F 3 "" H 9800 2750 50  0001 C CNN
	1    9800 2750
	1    0    0    -1  
$EndComp
Connection ~ 9800 2750
Wire Wire Line
	9800 2750 10300 2750
$Comp
L power:PWR_FLAG #FLG0102
U 1 1 5CE5947A
P 9800 2850
F 0 "#FLG0102" H 9800 2925 50  0001 C CNN
F 1 "PWR_FLAG" H 9800 3024 50  0001 C CNN
F 2 "" H 9800 2850 50  0001 C CNN
F 3 "" H 9800 2850 50  0001 C CNN
	1    9800 2850
	-1   0    0    1   
$EndComp
Connection ~ 9800 2850
Wire Wire Line
	9800 2850 10300 2850
Text Notes 5950 4600 0    50   ~ 0
IN4\nIN3\nIN2\nIN1
Text Notes 11400 6100 0    50   ~ 0
OUT4\nGND\nOUT3\nOUT2\nGND\nOUT1
$Comp
L NKK:M-2022NB SW104
U 3 1 5CE9D783
P 7700 8950
F 0 "SW104" H 7674 9175 50  0000 C CNN
F 1 "M-2022NB" H 7674 9084 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 8950 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 8950 50  0001 C CNN
F 4 "NKK" H 7800 9300 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 9400 50  0001 C CNN "Manufacturer Part Number"
	3    7700 8950
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0106
U 1 1 5CEA1D0B
P 7850 8950
F 0 "#PWR0106" H 7850 8700 50  0001 C CNN
F 1 "GND" H 7900 9000 50  0000 C CNN
F 2 "" H 7850 8950 50  0001 C CNN
F 3 "" H 7850 8950 50  0001 C CNN
	1    7850 8950
	1    0    0    -1  
$EndComp
Wire Wire Line
	7850 8950 7700 8950
$Comp
L NKK:M-2022NB SW103
U 3 1 5CEBBEAC
P 7700 7500
F 0 "SW103" H 7674 7725 50  0000 C CNN
F 1 "M-2022NB" H 7674 7634 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 7500 50  0001 C CNN
F 3 "" H 7500 7500 50  0001 C CNN
F 4 "NKK" H 7800 7850 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 7950 50  0001 C CNN "Manufacturer Part Number"
	3    7700 7500
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0105
U 1 1 5CEBBEB2
P 7850 7500
F 0 "#PWR0105" H 7850 7250 50  0001 C CNN
F 1 "GND" H 7900 7550 50  0000 C CNN
F 2 "" H 7850 7500 50  0001 C CNN
F 3 "" H 7850 7500 50  0001 C CNN
	1    7850 7500
	1    0    0    -1  
$EndComp
Wire Wire Line
	7850 7500 7700 7500
$Comp
L NKK:M-2022NB SW102
U 3 1 5CEFDB61
P 7700 6050
F 0 "SW102" H 7674 6275 50  0000 C CNN
F 1 "M-2022NB" H 7674 6184 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 6050 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 6050 50  0001 C CNN
F 4 "NKK" H 7800 6400 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 6500 50  0001 C CNN "Manufacturer Part Number"
	3    7700 6050
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0104
U 1 1 5CEFDB67
P 7850 6050
F 0 "#PWR0104" H 7850 5800 50  0001 C CNN
F 1 "GND" H 7900 6100 50  0000 C CNN
F 2 "" H 7850 6050 50  0001 C CNN
F 3 "" H 7850 6050 50  0001 C CNN
	1    7850 6050
	1    0    0    -1  
$EndComp
Wire Wire Line
	7850 6050 7700 6050
$Comp
L NKK:M-2022NB SW101
U 3 1 5CF02316
P 7700 4600
F 0 "SW101" H 7674 4825 50  0000 C CNN
F 1 "M-2022NB" H 7674 4734 50  0000 C CNN
F 2 "NKK:M-202XN-B" H 7500 4600 50  0001 C CNN
F 3 "http://akizukidenshi.com/download/ds/nkk/rocker_m.pdf" H 7500 4600 50  0001 C CNN
F 4 "NKK" H 7800 4950 50  0001 C CNN "Manufacturer"
F 5 "M-2022NB" H 7900 5050 50  0001 C CNN "Manufacturer Part Number"
	3    7700 4600
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0103
U 1 1 5CF0231C
P 7850 4600
F 0 "#PWR0103" H 7850 4350 50  0001 C CNN
F 1 "GND" H 7900 4650 50  0000 C CNN
F 2 "" H 7850 4600 50  0001 C CNN
F 3 "" H 7850 4600 50  0001 C CNN
	1    7850 4600
	1    0    0    -1  
$EndComp
Wire Wire Line
	7850 4600 7700 4600
$EndSCHEMATC
